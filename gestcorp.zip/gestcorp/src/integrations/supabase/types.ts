export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      anexos: {
        Row: {
          arquivo_url: string
          created_at: string
          id: string
          referencia_id: string
          referencia_tipo: Database["public"]["Enums"]["referencia_tipo"]
          tamanho: number | null
          tipo: string | null
          usuario_id: string
        }
        Insert: {
          arquivo_url: string
          created_at?: string
          id?: string
          referencia_id: string
          referencia_tipo: Database["public"]["Enums"]["referencia_tipo"]
          tamanho?: number | null
          tipo?: string | null
          usuario_id: string
        }
        Update: {
          arquivo_url?: string
          created_at?: string
          id?: string
          referencia_id?: string
          referencia_tipo?: Database["public"]["Enums"]["referencia_tipo"]
          tamanho?: number | null
          tipo?: string | null
          usuario_id?: string
        }
        Relationships: []
      }
      categorias_financeiras: {
        Row: {
          ativo: boolean
          codigo: string | null
          empresa_id: string
          id: string
          nome: string
          tipo: Database["public"]["Enums"]["categoria_tipo"]
        }
        Insert: {
          ativo?: boolean
          codigo?: string | null
          empresa_id: string
          id?: string
          nome: string
          tipo: Database["public"]["Enums"]["categoria_tipo"]
        }
        Update: {
          ativo?: boolean
          codigo?: string | null
          empresa_id?: string
          id?: string
          nome?: string
          tipo?: Database["public"]["Enums"]["categoria_tipo"]
        }
        Relationships: [
          {
            foreignKeyName: "categorias_financeiras_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      centros_custos: {
        Row: {
          ativo: boolean
          codigo: string | null
          empresa_id: string
          id: string
          nome: string
        }
        Insert: {
          ativo?: boolean
          codigo?: string | null
          empresa_id: string
          id?: string
          nome: string
        }
        Update: {
          ativo?: boolean
          codigo?: string | null
          empresa_id?: string
          id?: string
          nome?: string
        }
        Relationships: [
          {
            foreignKeyName: "centros_custos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      checklists_modelo: {
        Row: {
          ativo: boolean
          created_at: string
          descricao: string | null
          id: string
          itens: Json | null
          nome: string
          tipo_vistoria_id: string
          updated_at: string
          versao: number
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          itens?: Json | null
          nome: string
          tipo_vistoria_id: string
          updated_at?: string
          versao?: number
        }
        Update: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          itens?: Json | null
          nome?: string
          tipo_vistoria_id?: string
          updated_at?: string
          versao?: number
        }
        Relationships: [
          {
            foreignKeyName: "checklists_modelo_tipo_vistoria_id_fkey"
            columns: ["tipo_vistoria_id"]
            isOneToOne: false
            referencedRelation: "tipos_vistoria"
            referencedColumns: ["id"]
          },
        ]
      }
      clientes: {
        Row: {
          ativo: boolean
          contato: string | null
          created_at: string
          documento: string | null
          email: string | null
          empresa_id: string
          endereco: string | null
          id: string
          nome: string
          tags: string[] | null
          telefone: string | null
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          contato?: string | null
          created_at?: string
          documento?: string | null
          email?: string | null
          empresa_id: string
          endereco?: string | null
          id?: string
          nome: string
          tags?: string[] | null
          telefone?: string | null
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          contato?: string | null
          created_at?: string
          documento?: string | null
          email?: string | null
          empresa_id?: string
          endereco?: string | null
          id?: string
          nome?: string
          tags?: string[] | null
          telefone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "clientes_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      compras: {
        Row: {
          data: string
          empresa_id: string
          fornecedor_id: string
          id: string
          numero: string
          observacoes: string | null
          status: Database["public"]["Enums"]["compra_status"]
        }
        Insert: {
          data: string
          empresa_id: string
          fornecedor_id: string
          id?: string
          numero: string
          observacoes?: string | null
          status?: Database["public"]["Enums"]["compra_status"]
        }
        Update: {
          data?: string
          empresa_id?: string
          fornecedor_id?: string
          id?: string
          numero?: string
          observacoes?: string | null
          status?: Database["public"]["Enums"]["compra_status"]
        }
        Relationships: [
          {
            foreignKeyName: "compras_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "compras_fornecedor_id_fkey"
            columns: ["fornecedor_id"]
            isOneToOne: false
            referencedRelation: "fornecedores"
            referencedColumns: ["id"]
          },
        ]
      }
      compras_itens: {
        Row: {
          compra_id: string
          descricao: string
          id: string
          preco_unit: number
          produto_servico_id: string
          qtd: number
          total: number
        }
        Insert: {
          compra_id: string
          descricao: string
          id?: string
          preco_unit: number
          produto_servico_id: string
          qtd: number
          total: number
        }
        Update: {
          compra_id?: string
          descricao?: string
          id?: string
          preco_unit?: number
          produto_servico_id?: string
          qtd?: number
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "compras_itens_compra_id_fkey"
            columns: ["compra_id"]
            isOneToOne: false
            referencedRelation: "compras"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "compras_itens_produto_servico_id_fkey"
            columns: ["produto_servico_id"]
            isOneToOne: false
            referencedRelation: "produtos_servicos"
            referencedColumns: ["id"]
          },
        ]
      }
      contas_bancarias: {
        Row: {
          agencia: string | null
          banco: string | null
          conta: string | null
          created_at: string
          empresa_id: string
          id: string
          nome: string
          saldo_inicial: number
        }
        Insert: {
          agencia?: string | null
          banco?: string | null
          conta?: string | null
          created_at?: string
          empresa_id: string
          id?: string
          nome: string
          saldo_inicial?: number
        }
        Update: {
          agencia?: string | null
          banco?: string | null
          conta?: string | null
          created_at?: string
          empresa_id?: string
          id?: string
          nome?: string
          saldo_inicial?: number
        }
        Relationships: [
          {
            foreignKeyName: "contas_bancarias_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      contas_pagar: {
        Row: {
          categoria_id: string | null
          centro_custos_id: string | null
          compra_id: string | null
          desconto: number
          descricao: string
          emissao: string
          empresa_id: string
          fornecedor_id: string
          id: string
          juros: number
          multa: number
          observacoes: string | null
          status: Database["public"]["Enums"]["conta_status"]
          valor: number
          vencimento: string
        }
        Insert: {
          categoria_id?: string | null
          centro_custos_id?: string | null
          compra_id?: string | null
          desconto?: number
          descricao: string
          emissao: string
          empresa_id: string
          fornecedor_id: string
          id?: string
          juros?: number
          multa?: number
          observacoes?: string | null
          status?: Database["public"]["Enums"]["conta_status"]
          valor: number
          vencimento: string
        }
        Update: {
          categoria_id?: string | null
          centro_custos_id?: string | null
          compra_id?: string | null
          desconto?: number
          descricao?: string
          emissao?: string
          empresa_id?: string
          fornecedor_id?: string
          id?: string
          juros?: number
          multa?: number
          observacoes?: string | null
          status?: Database["public"]["Enums"]["conta_status"]
          valor?: number
          vencimento?: string
        }
        Relationships: [
          {
            foreignKeyName: "contas_pagar_categoria_id_fkey"
            columns: ["categoria_id"]
            isOneToOne: false
            referencedRelation: "categorias_financeiras"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_pagar_centro_custos_id_fkey"
            columns: ["centro_custos_id"]
            isOneToOne: false
            referencedRelation: "centros_custos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_pagar_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_pagar_fornecedor_id_fkey"
            columns: ["fornecedor_id"]
            isOneToOne: false
            referencedRelation: "fornecedores"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_contas_pagar_compra"
            columns: ["compra_id"]
            isOneToOne: false
            referencedRelation: "compras"
            referencedColumns: ["id"]
          },
        ]
      }
      contas_receber: {
        Row: {
          categoria_id: string | null
          centro_custos_id: string | null
          cliente_id: string
          desconto: number
          descricao: string
          emissao: string
          empresa_id: string
          id: string
          juros: number
          multa: number
          observacoes: string | null
          os_id: string | null
          status: Database["public"]["Enums"]["conta_status"]
          valor: number
          vencimento: string
        }
        Insert: {
          categoria_id?: string | null
          centro_custos_id?: string | null
          cliente_id: string
          desconto?: number
          descricao: string
          emissao: string
          empresa_id: string
          id?: string
          juros?: number
          multa?: number
          observacoes?: string | null
          os_id?: string | null
          status?: Database["public"]["Enums"]["conta_status"]
          valor: number
          vencimento: string
        }
        Update: {
          categoria_id?: string | null
          centro_custos_id?: string | null
          cliente_id?: string
          desconto?: number
          descricao?: string
          emissao?: string
          empresa_id?: string
          id?: string
          juros?: number
          multa?: number
          observacoes?: string | null
          os_id?: string | null
          status?: Database["public"]["Enums"]["conta_status"]
          valor?: number
          vencimento?: string
        }
        Relationships: [
          {
            foreignKeyName: "contas_receber_categoria_id_fkey"
            columns: ["categoria_id"]
            isOneToOne: false
            referencedRelation: "categorias_financeiras"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_receber_centro_custos_id_fkey"
            columns: ["centro_custos_id"]
            isOneToOne: false
            referencedRelation: "centros_custos"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_receber_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_receber_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contas_receber_os_id_fkey"
            columns: ["os_id"]
            isOneToOne: false
            referencedRelation: "ordens_servico"
            referencedColumns: ["id"]
          },
        ]
      }
      empresas: {
        Row: {
          cnpj: string | null
          created_at: string
          email: string | null
          endereco: string | null
          id: string
          nome_fantasia: string | null
          razao_social: string
          telefone: string | null
          updated_at: string
        }
        Insert: {
          cnpj?: string | null
          created_at?: string
          email?: string | null
          endereco?: string | null
          id?: string
          nome_fantasia?: string | null
          razao_social: string
          telefone?: string | null
          updated_at?: string
        }
        Update: {
          cnpj?: string | null
          created_at?: string
          email?: string | null
          endereco?: string | null
          id?: string
          nome_fantasia?: string | null
          razao_social?: string
          telefone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      execucoes_checklist: {
        Row: {
          checklist_modelo_id: string
          fim: string | null
          id: string
          inicio: string | null
          observacoes: string | null
          ordem_servico_id: string
          status: Database["public"]["Enums"]["execucao_status"]
          usuario_id: string
          versao_modelo: number
        }
        Insert: {
          checklist_modelo_id: string
          fim?: string | null
          id?: string
          inicio?: string | null
          observacoes?: string | null
          ordem_servico_id: string
          status?: Database["public"]["Enums"]["execucao_status"]
          usuario_id: string
          versao_modelo: number
        }
        Update: {
          checklist_modelo_id?: string
          fim?: string | null
          id?: string
          inicio?: string | null
          observacoes?: string | null
          ordem_servico_id?: string
          status?: Database["public"]["Enums"]["execucao_status"]
          usuario_id?: string
          versao_modelo?: number
        }
        Relationships: [
          {
            foreignKeyName: "execucoes_checklist_checklist_modelo_id_fkey"
            columns: ["checklist_modelo_id"]
            isOneToOne: false
            referencedRelation: "checklists_modelo"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "execucoes_checklist_ordem_servico_id_fkey"
            columns: ["ordem_servico_id"]
            isOneToOne: false
            referencedRelation: "ordens_servico"
            referencedColumns: ["id"]
          },
        ]
      }
      faturamentos: {
        Row: {
          cliente_id: string
          emissao: string
          id: string
          observacoes: string | null
          os_id: string
          total: number
        }
        Insert: {
          cliente_id: string
          emissao: string
          id?: string
          observacoes?: string | null
          os_id: string
          total: number
        }
        Update: {
          cliente_id?: string
          emissao?: string
          id?: string
          observacoes?: string | null
          os_id?: string
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "faturamentos_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "faturamentos_os_id_fkey"
            columns: ["os_id"]
            isOneToOne: false
            referencedRelation: "ordens_servico"
            referencedColumns: ["id"]
          },
        ]
      }
      fornecedores: {
        Row: {
          ativo: boolean
          cnpj: string | null
          contato: string | null
          created_at: string
          email: string | null
          empresa_id: string
          endereco: string | null
          id: string
          razao_social: string
          telefone: string | null
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          cnpj?: string | null
          contato?: string | null
          created_at?: string
          email?: string | null
          empresa_id: string
          endereco?: string | null
          id?: string
          razao_social: string
          telefone?: string | null
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          cnpj?: string | null
          contato?: string | null
          created_at?: string
          email?: string | null
          empresa_id?: string
          endereco?: string | null
          id?: string
          razao_social?: string
          telefone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "fornecedores_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      fotos: {
        Row: {
          capturada_em: string
          execucao_id: string
          geo_lat: number | null
          geo_lng: number | null
          id: string
          legenda: string | null
          url: string
          usuario_id: string
        }
        Insert: {
          capturada_em?: string
          execucao_id: string
          geo_lat?: number | null
          geo_lng?: number | null
          id?: string
          legenda?: string | null
          url: string
          usuario_id: string
        }
        Update: {
          capturada_em?: string
          execucao_id?: string
          geo_lat?: number | null
          geo_lng?: number | null
          id?: string
          legenda?: string | null
          url?: string
          usuario_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fotos_execucao_id_fkey"
            columns: ["execucao_id"]
            isOneToOne: false
            referencedRelation: "execucoes_checklist"
            referencedColumns: ["id"]
          },
        ]
      }
      historicos: {
        Row: {
          acao: string
          created_at: string
          descricao: string | null
          entidade: string
          entidade_id: string
          id: string
          usuario_id: string
        }
        Insert: {
          acao: string
          created_at?: string
          descricao?: string | null
          entidade: string
          entidade_id: string
          id?: string
          usuario_id: string
        }
        Update: {
          acao?: string
          created_at?: string
          descricao?: string | null
          entidade?: string
          entidade_id?: string
          id?: string
          usuario_id?: string
        }
        Relationships: []
      }
      locais_vistoria: {
        Row: {
          cep: string | null
          cidade: string | null
          endereco: string
          id: string
          latitude: number | null
          longitude: number | null
          ordem_servico_id: string
          uf: string | null
        }
        Insert: {
          cep?: string | null
          cidade?: string | null
          endereco: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          ordem_servico_id: string
          uf?: string | null
        }
        Update: {
          cep?: string | null
          cidade?: string | null
          endereco?: string
          id?: string
          latitude?: number | null
          longitude?: number | null
          ordem_servico_id?: string
          uf?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "locais_vistoria_ordem_servico_id_fkey"
            columns: ["ordem_servico_id"]
            isOneToOne: false
            referencedRelation: "ordens_servico"
            referencedColumns: ["id"]
          },
        ]
      }
      movimentos_bancarios: {
        Row: {
          conciliado: boolean
          conta_id: string
          created_at: string
          data: string
          descricao: string | null
          id: string
          origem_id: string | null
          origem_tipo: Database["public"]["Enums"]["origem_tipo"] | null
          tipo: Database["public"]["Enums"]["movimento_tipo"]
          valor: number
        }
        Insert: {
          conciliado?: boolean
          conta_id: string
          created_at?: string
          data: string
          descricao?: string | null
          id?: string
          origem_id?: string | null
          origem_tipo?: Database["public"]["Enums"]["origem_tipo"] | null
          tipo: Database["public"]["Enums"]["movimento_tipo"]
          valor: number
        }
        Update: {
          conciliado?: boolean
          conta_id?: string
          created_at?: string
          data?: string
          descricao?: string | null
          id?: string
          origem_id?: string | null
          origem_tipo?: Database["public"]["Enums"]["origem_tipo"] | null
          tipo?: Database["public"]["Enums"]["movimento_tipo"]
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "movimentos_bancarios_conta_id_fkey"
            columns: ["conta_id"]
            isOneToOne: false
            referencedRelation: "contas_bancarias"
            referencedColumns: ["id"]
          },
        ]
      }
      ordens_servico: {
        Row: {
          cliente_id: string
          codigo: string
          created_at: string
          data_agendada: string | null
          descricao: string | null
          empresa_id: string
          id: string
          prioridade: Database["public"]["Enums"]["os_prioridade"]
          responsavel_id: string | null
          status: Database["public"]["Enums"]["os_status"]
          tipo_vistoria_id: string
          updated_at: string
        }
        Insert: {
          cliente_id: string
          codigo: string
          created_at?: string
          data_agendada?: string | null
          descricao?: string | null
          empresa_id: string
          id?: string
          prioridade?: Database["public"]["Enums"]["os_prioridade"]
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["os_status"]
          tipo_vistoria_id: string
          updated_at?: string
        }
        Update: {
          cliente_id?: string
          codigo?: string
          created_at?: string
          data_agendada?: string | null
          descricao?: string | null
          empresa_id?: string
          id?: string
          prioridade?: Database["public"]["Enums"]["os_prioridade"]
          responsavel_id?: string | null
          status?: Database["public"]["Enums"]["os_status"]
          tipo_vistoria_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ordens_servico_cliente_id_fkey"
            columns: ["cliente_id"]
            isOneToOne: false
            referencedRelation: "clientes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_servico_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ordens_servico_responsavel_id_fkey"
            columns: ["responsavel_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["user_id"]
          },
          {
            foreignKeyName: "ordens_servico_tipo_vistoria_id_fkey"
            columns: ["tipo_vistoria_id"]
            isOneToOne: false
            referencedRelation: "tipos_vistoria"
            referencedColumns: ["id"]
          },
        ]
      }
      pagamentos: {
        Row: {
          comprovante_url: string | null
          conta_bancaria_id: string
          conta_pagar_id: string
          data: string
          forma_pagamento: Database["public"]["Enums"]["forma_pagamento"]
          id: string
          valor: number
        }
        Insert: {
          comprovante_url?: string | null
          conta_bancaria_id: string
          conta_pagar_id: string
          data: string
          forma_pagamento: Database["public"]["Enums"]["forma_pagamento"]
          id?: string
          valor: number
        }
        Update: {
          comprovante_url?: string | null
          conta_bancaria_id?: string
          conta_pagar_id?: string
          data?: string
          forma_pagamento?: Database["public"]["Enums"]["forma_pagamento"]
          id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "pagamentos_conta_bancaria_id_fkey"
            columns: ["conta_bancaria_id"]
            isOneToOne: false
            referencedRelation: "contas_bancarias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pagamentos_conta_pagar_id_fkey"
            columns: ["conta_pagar_id"]
            isOneToOne: false
            referencedRelation: "contas_pagar"
            referencedColumns: ["id"]
          },
        ]
      }
      planos: {
        Row: {
          ativo: boolean
          created_at: string
          descricao: string | null
          id: string
          limite_empresas: number | null
          limite_os_mes: number | null
          limite_usuarios: number | null
          modulos_incluidos: string[] | null
          nome: string
          preco_mensal: number
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          limite_empresas?: number | null
          limite_os_mes?: number | null
          limite_usuarios?: number | null
          modulos_incluidos?: string[] | null
          nome: string
          preco_mensal?: number
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          limite_empresas?: number | null
          limite_os_mes?: number | null
          limite_usuarios?: number | null
          modulos_incluidos?: string[] | null
          nome?: string
          preco_mensal?: number
          updated_at?: string
        }
        Relationships: []
      }
      produtos_servicos: {
        Row: {
          ativo: boolean
          codigo: string | null
          custo: number | null
          empresa_id: string
          id: string
          nome: string
          preco_venda: number | null
          tipo: Database["public"]["Enums"]["produto_tipo"]
          unidade: string | null
        }
        Insert: {
          ativo?: boolean
          codigo?: string | null
          custo?: number | null
          empresa_id: string
          id?: string
          nome: string
          preco_venda?: number | null
          tipo: Database["public"]["Enums"]["produto_tipo"]
          unidade?: string | null
        }
        Update: {
          ativo?: boolean
          codigo?: string | null
          custo?: number | null
          empresa_id?: string
          id?: string
          nome?: string
          preco_venda?: number | null
          tipo?: Database["public"]["Enums"]["produto_tipo"]
          unidade?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "produtos_servicos_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          cnpj: string | null
          created_at: string
          email: string
          empresa_nome: string | null
          id: string
          is_admin: boolean
          nome: string
          telefone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          cnpj?: string | null
          created_at?: string
          email: string
          empresa_nome?: string | null
          id?: string
          is_admin?: boolean
          nome: string
          telefone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          cnpj?: string | null
          created_at?: string
          email?: string
          empresa_nome?: string | null
          id?: string
          is_admin?: boolean
          nome?: string
          telefone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      recebimentos: {
        Row: {
          comprovante_url: string | null
          conta_bancaria_id: string
          conta_receber_id: string
          data: string
          forma_pagamento: Database["public"]["Enums"]["forma_pagamento"]
          id: string
          valor: number
        }
        Insert: {
          comprovante_url?: string | null
          conta_bancaria_id: string
          conta_receber_id: string
          data: string
          forma_pagamento: Database["public"]["Enums"]["forma_pagamento"]
          id?: string
          valor: number
        }
        Update: {
          comprovante_url?: string | null
          conta_bancaria_id?: string
          conta_receber_id?: string
          data?: string
          forma_pagamento?: Database["public"]["Enums"]["forma_pagamento"]
          id?: string
          valor?: number
        }
        Relationships: [
          {
            foreignKeyName: "recebimentos_conta_bancaria_id_fkey"
            columns: ["conta_bancaria_id"]
            isOneToOne: false
            referencedRelation: "contas_bancarias"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "recebimentos_conta_receber_id_fkey"
            columns: ["conta_receber_id"]
            isOneToOne: false
            referencedRelation: "contas_receber"
            referencedColumns: ["id"]
          },
        ]
      }
      respostas_checklist: {
        Row: {
          execucao_id: string
          id: string
          item_id: string
          observacao: string | null
          pergunta: string
          resposta: Json | null
          tipo: Database["public"]["Enums"]["resposta_tipo"]
        }
        Insert: {
          execucao_id: string
          id?: string
          item_id: string
          observacao?: string | null
          pergunta: string
          resposta?: Json | null
          tipo: Database["public"]["Enums"]["resposta_tipo"]
        }
        Update: {
          execucao_id?: string
          id?: string
          item_id?: string
          observacao?: string | null
          pergunta?: string
          resposta?: Json | null
          tipo?: Database["public"]["Enums"]["resposta_tipo"]
        }
        Relationships: [
          {
            foreignKeyName: "respostas_checklist_execucao_id_fkey"
            columns: ["execucao_id"]
            isOneToOne: false
            referencedRelation: "execucoes_checklist"
            referencedColumns: ["id"]
          },
        ]
      }
      subscribers: {
        Row: {
          created_at: string
          email: string
          id: string
          plano_id: string | null
          status: string
          stripe_customer_id: string | null
          subscribed: boolean
          subscription_end: string | null
          subscription_tier: string | null
          trial_end: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          plano_id?: string | null
          status?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          trial_end?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          plano_id?: string | null
          status?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          trial_end?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "subscribers_plano_id_fkey"
            columns: ["plano_id"]
            isOneToOne: false
            referencedRelation: "planos"
            referencedColumns: ["id"]
          },
        ]
      }
      tenant_members: {
        Row: {
          id: string
          invited_at: string | null
          invited_by: string | null
          joined_at: string | null
          role: string
          tenant_id: string
          user_id: string
        }
        Insert: {
          id?: string
          invited_at?: string | null
          invited_by?: string | null
          joined_at?: string | null
          role?: string
          tenant_id: string
          user_id: string
        }
        Update: {
          id?: string
          invited_at?: string | null
          invited_by?: string | null
          joined_at?: string | null
          role?: string
          tenant_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tenant_members_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      tenants: {
        Row: {
          ativo: boolean
          created_at: string
          empresa_id: string
          id: string
          owner_id: string
          plano_id: string | null
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          empresa_id: string
          id?: string
          owner_id: string
          plano_id?: string | null
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          empresa_id?: string
          id?: string
          owner_id?: string
          plano_id?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "tenants_empresa_id_fkey"
            columns: ["empresa_id"]
            isOneToOne: false
            referencedRelation: "empresas"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tenants_plano_id_fkey"
            columns: ["plano_id"]
            isOneToOne: false
            referencedRelation: "planos"
            referencedColumns: ["id"]
          },
        ]
      }
      tipos_vistoria: {
        Row: {
          ativo: boolean
          created_at: string
          descricao: string | null
          id: string
          nome: string
          updated_at: string
        }
        Insert: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          nome: string
          updated_at?: string
        }
        Update: {
          ativo?: boolean
          created_at?: string
          descricao?: string | null
          id?: string
          nome?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          created_by: string | null
          empresa_id: string
          id: string
          permissions: Json | null
          role: Database["public"]["Enums"]["user_role"]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          empresa_id: string
          id?: string
          permissions?: Json | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          empresa_id?: string
          id?: string
          permissions?: Json | null
          role?: Database["public"]["Enums"]["user_role"]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_user_permission: {
        Args: { _empresa_id: string; _permission?: string }
        Returns: boolean
      }
      get_user_empresa_access: { Args: { user_id: string }; Returns: string[] }
    }
    Enums: {
      categoria_tipo: "receita" | "despesa"
      compra_status:
        | "rascunho"
        | "aprovada"
        | "parcial"
        | "concluida"
        | "cancelada"
      conta_status: "aberto" | "parcial" | "liquidado" | "cancelado"
      execucao_status:
        | "em_execucao"
        | "pendente_validacao"
        | "aprovado"
        | "reprovado"
      forma_pagamento:
        | "dinheiro"
        | "pix"
        | "transferencia"
        | "boleto"
        | "cartao"
        | "outro"
      movimento_tipo: "entrada" | "saida" | "transferencia"
      origem_tipo: "receber" | "pagar" | "ajuste" | "transferencia"
      os_prioridade: "baixa" | "media" | "alta"
      os_status:
        | "rascunho"
        | "agendada"
        | "em_execucao"
        | "pendente_dados"
        | "concluida"
        | "cancelada"
      produto_tipo: "produto" | "servico"
      referencia_tipo: "os" | "execucao" | "financeiro"
      resposta_tipo:
        | "texto"
        | "numero"
        | "booleano"
        | "opcao"
        | "foto"
        | "anexo"
      user_role: "admin" | "supervisor" | "usuario"
      user_status: "ativo" | "inativo"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      categoria_tipo: ["receita", "despesa"],
      compra_status: [
        "rascunho",
        "aprovada",
        "parcial",
        "concluida",
        "cancelada",
      ],
      conta_status: ["aberto", "parcial", "liquidado", "cancelado"],
      execucao_status: [
        "em_execucao",
        "pendente_validacao",
        "aprovado",
        "reprovado",
      ],
      forma_pagamento: [
        "dinheiro",
        "pix",
        "transferencia",
        "boleto",
        "cartao",
        "outro",
      ],
      movimento_tipo: ["entrada", "saida", "transferencia"],
      origem_tipo: ["receber", "pagar", "ajuste", "transferencia"],
      os_prioridade: ["baixa", "media", "alta"],
      os_status: [
        "rascunho",
        "agendada",
        "em_execucao",
        "pendente_dados",
        "concluida",
        "cancelada",
      ],
      produto_tipo: ["produto", "servico"],
      referencia_tipo: ["os", "execucao", "financeiro"],
      resposta_tipo: ["texto", "numero", "booleano", "opcao", "foto", "anexo"],
      user_role: ["admin", "supervisor", "usuario"],
      user_status: ["ativo", "inativo"],
    },
  },
} as const
