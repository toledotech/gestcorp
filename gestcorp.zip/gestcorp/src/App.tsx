import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "./contexts/AuthContext";
import { ProtectedRoute } from "./components/ProtectedRoute";
import { MainLayout } from "@/components/layout/MainLayout";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import DashboardFinanceiro from "./pages/DashboardFinanceiro";
import Planos from "./pages/Planos";
import Admin from "./pages/Admin";
import Agenda from "./pages/Agenda";
import Auth from "./pages/Auth";
import ResetPassword from "./pages/ResetPassword";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/" element={
              <ProtectedRoute>
                <MainLayout>
                  <Dashboard />
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/dashboard" element={
              <ProtectedRoute>
                <MainLayout>
                  <Dashboard />
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/dashboard-financeiro" element={
              <ProtectedRoute>
                <MainLayout>
                  <DashboardFinanceiro />
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/planos" element={
              <ProtectedRoute>
                <MainLayout>
                  <Planos />
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/admin" element={
              <ProtectedRoute>
                <MainLayout>
                  <Admin />
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/ordens-servico" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Ordens de Serviço</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/agenda" element={
              <ProtectedRoute>
                <MainLayout>
                  <Agenda />
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/checklists" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Checklists</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/execucoes" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Execuções</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/contas-receber" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Contas a Receber</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/contas-pagar" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Contas a Pagar</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/fluxo-caixa" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Fluxo de Caixa</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/faturamento" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Faturamento</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/clientes" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Clientes</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/empresas" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Empresas</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/usuarios" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Usuários</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            <Route path="/configuracoes" element={
              <ProtectedRoute>
                <MainLayout>
                  <div className="p-6"><h1 className="text-2xl font-bold">Configurações</h1><p className="text-muted-foreground">Em desenvolvimento...</p></div>
                </MainLayout>
              </ProtectedRoute>
            } />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;