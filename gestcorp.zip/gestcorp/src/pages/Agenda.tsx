import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Calendar as CalendarIcon, 
  Clock, 
  MapPin, 
  User, 
  Plus,
  Filter,
  Search,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { format, isSameDay, addMonths, subMonths } from "date-fns";
import { ptBR } from "date-fns/locale";

const Agenda = () => {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<"calendar" | "list">("calendar");
  const [isNewEventOpen, setIsNewEventOpen] = useState(false);

  // Mock data para eventos/agendamentos
  const eventos = [
    {
      id: "1",
      titulo: "Vistoria Residencial - Apto 101",
      cliente: "João Silva",
      tipo: "residencial",
      data: new Date(2024, 8, 20, 9, 0),
      duracao: 120,
      endereco: "Rua das Flores, 123 - Centro",
      vistoriador: "Maria Santos",
      status: "confirmada",
      observacoes: "Cliente solicitou vistoria completa"
    },
    {
      id: "2",
      titulo: "Vistoria Comercial - Loja Shopping",
      cliente: "Empresa ABC Ltda",
      tipo: "comercial",
      data: new Date(2024, 8, 20, 14, 30),
      duracao: 180,
      endereco: "Shopping Center Norte - Loja 45",
      vistoriador: "Pedro Costa",
      status: "pendente",
      observacoes: ""
    },
    {
      id: "3",
      titulo: "Vistoria Industrial - Galpão",
      cliente: "Indústria XYZ",
      tipo: "industrial",
      data: new Date(2024, 8, 21, 8, 0),
      duracao: 240,
      endereco: "Distrito Industrial - Rua A, 500",
      vistoriador: "Ana Lima",
      status: "confirmada",
      observacoes: "Trazer equipamentos especiais"
    },
    {
      id: "4",
      titulo: "Reunião de Alinhamento",
      cliente: "Equipe Interna",
      tipo: "reuniao",
      data: new Date(2024, 8, 22, 10, 0),
      duracao: 60,
      endereco: "Escritório - Sala de Reuniões",
      vistoriador: "Todos",
      status: "confirmada",
      observacoes: "Revisão dos processos mensais"
    }
  ];

  const getEventosData = (data: Date) => {
    return eventos.filter(evento => isSameDay(evento.data, data));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmada":
        return "bg-success/10 text-success border-success/20";
      case "pendente":
        return "bg-warning/10 text-warning border-warning/20";
      case "cancelada":
        return "bg-destructive/10 text-destructive border-destructive/20";
      default:
        return "bg-muted/10 text-muted-foreground border-muted/20";
    }
  };

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case "residencial":
        return "bg-primary/10 text-primary border-primary/20";
      case "comercial":
        return "bg-secondary/10 text-secondary border-secondary/20";
      case "industrial":
        return "bg-accent/10 text-accent border-accent/20";
      case "reuniao":
        return "bg-muted/10 text-muted-foreground border-muted/20";
      default:
        return "bg-muted/10 text-muted-foreground border-muted/20";
    }
  };

  const eventosDoMes = eventos.filter(evento => 
    evento.data.getMonth() === currentMonth.getMonth() &&
    evento.data.getFullYear() === currentMonth.getFullYear()
  );

  const diasComEventos = eventosDoMes.map(evento => evento.data);

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Agenda
          </h1>
          <p className="text-muted-foreground mt-1">
            Gerencie seus agendamentos e vistorias
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex bg-muted rounded-lg p-1">
            <Button
              variant={viewMode === "calendar" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("calendar")}
              className="rounded-md"
            >
              <CalendarIcon className="h-4 w-4 mr-2" />
              Calendário
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "ghost"}
              size="sm"
              onClick={() => setViewMode("list")}
              className="rounded-md"
            >
              <Clock className="h-4 w-4 mr-2" />
              Lista
            </Button>
          </div>
          
          <Dialog open={isNewEventOpen} onOpenChange={setIsNewEventOpen}>
            <DialogTrigger asChild>
              <Button variant="premium" className="shadow-elegant">
                <Plus className="mr-2 h-4 w-4" />
                Novo Agendamento
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[600px]">
              <DialogHeader>
                <DialogTitle>Novo Agendamento</DialogTitle>
                <DialogDescription>
                  Crie um novo agendamento para vistoria ou reunião
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="titulo">Título</Label>
                    <Input id="titulo" placeholder="Título do agendamento" />
                  </div>
                  <div>
                    <Label htmlFor="cliente">Cliente</Label>
                    <Input id="cliente" placeholder="Nome do cliente" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="tipo">Tipo</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="residencial">Residencial</SelectItem>
                        <SelectItem value="comercial">Comercial</SelectItem>
                        <SelectItem value="industrial">Industrial</SelectItem>
                        <SelectItem value="reuniao">Reunião</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="vistoriador">Vistoriador</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione o vistoriador" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="maria">Maria Santos</SelectItem>
                        <SelectItem value="pedro">Pedro Costa</SelectItem>
                        <SelectItem value="ana">Ana Lima</SelectItem>
                        <SelectItem value="joao">João Silva</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="data">Data</Label>
                    <Input id="data" type="date" />
                  </div>
                  <div>
                    <Label htmlFor="horario">Horário</Label>
                    <Input id="horario" type="time" />
                  </div>
                  <div>
                    <Label htmlFor="duracao">Duração (min)</Label>
                    <Input id="duracao" type="number" placeholder="120" />
                  </div>
                </div>
                <div>
                  <Label htmlFor="endereco">Endereço</Label>
                  <Input id="endereco" placeholder="Endereço completo da vistoria" />
                </div>
                <div>
                  <Label htmlFor="observacoes">Observações</Label>
                  <Textarea id="observacoes" placeholder="Observações adicionais..." />
                </div>
              </div>
              <div className="flex justify-end gap-3">
                <Button variant="outline" onClick={() => setIsNewEventOpen(false)}>
                  Cancelar
                </Button>
                <Button onClick={() => setIsNewEventOpen(false)}>
                  Salvar Agendamento
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Content */}
      {viewMode === "calendar" ? (
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Calendar */}
          <div className="lg:col-span-2">
            <Card className="bg-gradient-card shadow-card border-0">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <CalendarIcon className="h-5 w-5 text-primary" />
                    {format(currentMonth, "MMMM yyyy", { locale: ptBR })}
                  </CardTitle>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  month={currentMonth}
                  onMonthChange={setCurrentMonth}
                  locale={ptBR}
                  className="w-full"
                  modifiers={{
                    hasEvents: diasComEventos
                  }}
                  modifiersStyles={{
                    hasEvents: {
                      backgroundColor: "hsl(var(--primary) / 0.1)",
                      color: "hsl(var(--primary))",
                      fontWeight: "600"
                    }
                  }}
                />
              </CardContent>
            </Card>
          </div>

          {/* Events for selected date */}
          <div>
            <Card className="bg-gradient-card shadow-card border-0">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-primary" />
                  {format(selectedDate, "dd/MM/yyyy", { locale: ptBR })}
                </CardTitle>
                <CardDescription>
                  Agendamentos do dia selecionado
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {getEventosData(selectedDate).length === 0 ? (
                    <p className="text-muted-foreground text-center py-4">
                      Nenhum agendamento para este dia
                    </p>
                  ) : (
                    getEventosData(selectedDate).map((evento) => (
                      <div key={evento.id} className="p-3 rounded-lg bg-muted/30 space-y-2">
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium text-sm">{evento.titulo}</h4>
                          <Badge className={getStatusColor(evento.status)} variant="outline">
                            {evento.status}
                          </Badge>
                        </div>
                        <div className="space-y-1 text-xs">
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            {format(evento.data, "HH:mm")} ({evento.duracao}min)
                          </div>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <User className="h-3 w-3" />
                            {evento.vistoriador}
                          </div>
                          <div className="flex items-center gap-2 text-muted-foreground">
                            <MapPin className="h-3 w-3" />
                            {evento.endereco}
                          </div>
                        </div>
                        <Badge className={getTipoColor(evento.tipo)} variant="outline">
                          {evento.tipo}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        // List View
        <div className="space-y-4">
          {/* Filters */}
          <Card className="bg-gradient-card shadow-card border-0">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Buscar agendamentos..."
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select>
                  <SelectTrigger className="w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os tipos</SelectItem>
                    <SelectItem value="residencial">Residencial</SelectItem>
                    <SelectItem value="comercial">Comercial</SelectItem>
                    <SelectItem value="industrial">Industrial</SelectItem>
                    <SelectItem value="reuniao">Reunião</SelectItem>
                  </SelectContent>
                </Select>
                <Select>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todos">Todos os status</SelectItem>
                    <SelectItem value="confirmada">Confirmada</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="cancelada">Cancelada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Events List */}
          <div className="space-y-3">
            {eventos.map((evento) => (
              <Card key={evento.id} className="bg-gradient-card shadow-card border-0">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-3 flex-1">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold">{evento.titulo}</h3>
                        <Badge className={getTipoColor(evento.tipo)} variant="outline">
                          {evento.tipo}
                        </Badge>
                        <Badge className={getStatusColor(evento.status)} variant="outline">
                          {evento.status}
                        </Badge>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Cliente</p>
                          <p className="font-medium">{evento.cliente}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Vistoriador</p>
                          <p className="font-medium">{evento.vistoriador}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center gap-2">
                          <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                          <span>{format(evento.data, "dd/MM/yyyy")}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="h-4 w-4 text-muted-foreground" />
                          <span>{format(evento.data, "HH:mm")} ({evento.duracao}min)</span>
                        </div>
                      </div>

                      <div className="flex items-start gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                        <span className="text-muted-foreground">{evento.endereco}</span>
                      </div>

                      {evento.observacoes && (
                        <div className="text-sm">
                          <p className="text-muted-foreground">Observações</p>
                          <p className="text-sm bg-muted/30 p-2 rounded">{evento.observacoes}</p>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2 ml-4">
                      <Button variant="outline" size="sm">
                        Editar
                      </Button>
                      <Button variant="outline" size="sm">
                        Cancelar
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default Agenda;