import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, Star, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

interface Plano {
  id: string;
  nome: string;
  descricao: string;
  preco_mensal: number;
  modulos_incluidos: string[];
  ativo: boolean;
}

interface Subscriber {
  status: string;
  subscription_tier: string;
  trial_end: string;
  subscription_end: string;
}

const Planos = () => {
  const [planos, setPlanos] = useState<Plano[]>([]);
  const [subscriber, setSubscriber] = useState<Subscriber | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    loadPlanos();
    loadSubscriber();
  }, [user]);

  const loadPlanos = async () => {
    try {
      const { data, error } = await supabase
        .from('planos')
        .select('*')
        .eq('ativo', true)
        .order('preco_mensal', { ascending: true });

      if (error) throw error;
      setPlanos(data || []);
    } catch (error) {
      console.error('Erro ao carregar planos:', error);
      toast({
        title: "Erro ao carregar planos",
        description: "Tente novamente em alguns instantes",
        variant: "destructive",
      });
    }
  };

  const loadSubscriber = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('subscribers')
        .select('status, subscription_tier, trial_end, subscription_end')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setSubscriber(data);
    } catch (error) {
      console.error('Erro ao carregar assinatura:', error);
    } finally {
      setLoading(false);
    }
  };

  const getPlanoIcon = (nome: string) => {
    switch (nome.toLowerCase()) {
      case 'básico': return <Star className="h-6 w-6" />;
      case 'enterprise': return <Crown className="h-6 w-6" />;
      default: return <Zap className="h-6 w-6" />;
    }
  };

  const getStatusBadge = () => {
    if (!subscriber) return null;

    switch (subscriber.status) {
      case 'trial':
        const trialEnd = new Date(subscriber.trial_end);
        const daysLeft = Math.ceil((trialEnd.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        return <Badge variant="outline">Trial - {daysLeft} dias restantes</Badge>;
      case 'active':
        return <Badge className="bg-green-500">Assinatura Ativa</Badge>;
      case 'past_due':
        return <Badge variant="destructive">Pagamento Pendente</Badge>;
      case 'canceled':
        return <Badge variant="secondary">Cancelada</Badge>;
      default:
        return <Badge variant="outline">Status: {subscriber.status}</Badge>;
    }
  };

  const isCurrentPlan = (planoNome: string) => {
    return subscriber?.subscription_tier === planoNome;
  };

  const handleSelectPlan = async (plano: Plano) => {
    if (plano.preco_mensal === 0) {
      toast({
        title: "Plano gratuito",
        description: "Este plano não requer pagamento",
      });
      return;
    }

    toast({
      title: "Integração Stripe pendente",
      description: "Em breve você poderá assinar este plano. Configure sua conta Stripe para habilitar pagamentos.",
    });
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
              <p className="text-muted-foreground">Carregando planos...</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Escolha seu Plano</h1>
          <p className="text-muted-foreground mb-4">
            Selecione o plano ideal para sua empresa
          </p>
          {getStatusBadge()}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {planos.map((plano) => (
            <Card 
              key={plano.id} 
              className={`relative ${
                isCurrentPlan(plano.nome) 
                  ? 'ring-2 ring-primary shadow-lg scale-105' 
                  : 'hover:shadow-lg transition-all duration-200'
              }`}
            >
              {isCurrentPlan(plano.nome) && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-primary text-primary-foreground">
                    Plano Atual
                  </Badge>
                </div>
              )}
              
              <CardHeader className="text-center">
                <div className="flex justify-center mb-4">
                  <div className={`p-3 rounded-full ${
                    plano.nome === 'Enterprise' 
                      ? 'bg-gradient-primary text-white' 
                      : 'bg-primary/10 text-primary'
                  }`}>
                    {getPlanoIcon(plano.nome)}
                  </div>
                </div>
                
                <CardTitle className="text-2xl">{plano.nome}</CardTitle>
                <CardDescription className="text-sm">
                  {plano.descricao}
                </CardDescription>
                
                <div className="py-4">
                  <div className="text-4xl font-bold">
                    {plano.preco_mensal === 0 ? (
                      'Gratuito'
                    ) : (
                      <>
                        R$ {plano.preco_mensal.toFixed(2).replace('.', ',')}
                        <span className="text-sm font-normal text-muted-foreground">/mês</span>
                      </>
                    )}
                  </div>
                  {plano.preco_mensal === 0 && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Para sempre
                    </p>
                  )}
                </div>
              </CardHeader>
              
              <CardContent>
                <ul className="space-y-3 mb-6">
                  {plano.modulos_incluidos.map((modulo) => (
                    <li key={modulo} className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span className="text-sm capitalize">
                        {modulo === 'operacao' ? 'Operação (OS, Agenda, Checklists)' :
                         modulo === 'financeiro' ? 'Módulo Financeiro Completo' :
                         modulo === 'relatorios' ? 'Relatórios e Analytics' :
                         modulo === 'admin' ? 'Painel Administrativo' :
                         modulo}
                      </span>
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className="w-full"
                  variant={plano.nome === 'Enterprise' ? "premium" : "outline"}
                  onClick={() => handleSelectPlan(plano)}
                  disabled={isCurrentPlan(plano.nome)}
                >
                  {isCurrentPlan(plano.nome) 
                    ? 'Plano Atual' 
                    : plano.preco_mensal === 0 
                      ? 'Continuar Gratuito' 
                      : 'Assinar Agora'}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Card className="max-w-2xl mx-auto">
            <CardHeader>
              <CardTitle className="text-xl">Período de Teste Gratuito</CardTitle>
              <CardDescription>
                Experimente todos os recursos do GestCorp por 14 dias, sem compromisso
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>✓ Todos os módulos liberados durante o trial</li>
                <li>✓ Suporte completo por email</li>
                <li>✓ Migração de dados incluída</li>
                <li>✓ Cancele a qualquer momento</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Planos;