import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, Building2, CreditCard, Settings, Search, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";

interface UserProfile {
  id: string;
  nome: string;
  email: string;
  empresa_nome: string;
  created_at: string;
  is_admin: boolean;
  subscriber?: {
    status: string;
    subscription_tier: string;
    trial_end: string;
  };
}

interface Plano {
  id: string;
  nome: string;
  preco_mensal: number;
  ativo: boolean;
}

const Admin = () => {
  const [usuarios, setUsuarios] = useState<UserProfile[]>([]);
  const [planos, setPlanos] = useState<Plano[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const { user } = useAuth();

  const [newPlan, setNewPlan] = useState({
    nome: "",
    descricao: "",
    preco_mensal: 0
  });

  useEffect(() => {
    checkAdminAccess();
    loadData();
  }, [user]);

  const checkAdminAccess = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('is_admin')
        .eq('user_id', user.id)
        .single();

      if (error || !data?.is_admin) {
        toast({
          title: "Acesso negado",
          description: "Você não tem permissão para acessar esta página",
          variant: "destructive",
        });
        return;
      }
    } catch (error) {
      console.error('Erro ao verificar permissões:', error);
    }
  };

  const loadData = async () => {
    try {
      // Carregar usuários
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select(`
          *,
          subscribers (
            status,
            subscription_tier,
            trial_end
          )
        `)
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Carregar planos
      const { data: planosData, error: planosError } = await supabase
        .from('planos')
        .select('*')
        .order('preco_mensal', { ascending: true });

      if (planosError) throw planosError;

      setUsuarios(profiles || []);
      setPlanos(planosData || []);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast({
        title: "Erro ao carregar dados",
        description: "Tente novamente em alguns instantes",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreatePlan = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const { error } = await supabase
        .from('planos')
        .insert([{
          nome: newPlan.nome,
          descricao: newPlan.descricao,
          preco_mensal: newPlan.preco_mensal,
          modulos_incluidos: ['dashboard', 'operacao', 'relatorios']
        }]);

      if (error) throw error;

      toast({
        title: "Plano criado",
        description: "Novo plano adicionado com sucesso",
      });

      setNewPlan({ nome: "", descricao: "", preco_mensal: 0 });
      loadData();
    } catch (error) {
      console.error('Erro ao criar plano:', error);
      toast({
        title: "Erro ao criar plano",
        description: "Tente novamente em alguns instantes",
        variant: "destructive",
      });
    }
  };

  const togglePlanStatus = async (planId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('planos')
        .update({ ativo: !currentStatus })
        .eq('id', planId);

      if (error) throw error;

      toast({
        title: "Status atualizado",
        description: `Plano ${!currentStatus ? 'ativado' : 'desativado'} com sucesso`,
      });

      loadData();
    } catch (error) {
      console.error('Erro ao atualizar plano:', error);
      toast({
        title: "Erro ao atualizar plano",
        variant: "destructive",
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'trial':
        return <Badge variant="outline">Trial</Badge>;
      case 'active':
        return <Badge className="bg-green-500">Ativo</Badge>;
      case 'past_due':
        return <Badge variant="destructive">Pendente</Badge>;
      case 'canceled':
        return <Badge variant="secondary">Cancelado</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const filteredUsuarios = usuarios.filter(usuario => 
    usuario.nome.toLowerCase().includes(searchTerm.toLowerCase()) ||
    usuario.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (usuario.empresa_nome && usuario.empresa_nome.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const totalUsuarios = usuarios.length;
  const usuariosAtivos = usuarios.filter(u => u.subscriber?.status === 'active').length;
  const usuariosTrials = usuarios.filter(u => u.subscriber?.status === 'trial').length;

  if (loading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-center h-64">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
            <p className="text-muted-foreground">Carregando dados administrativos...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center gap-2 mb-6">
          <Shield className="h-6 w-6 text-primary" />
          <h1 className="text-3xl font-bold">Painel Administrativo</h1>
        </div>

        {/* Cards de Estatísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Usuários</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalUsuarios}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Assinantes Ativos</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{usuariosAtivos}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Em Trial</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{usuariosTrials}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Taxa Conversão</CardTitle>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {totalUsuarios > 0 ? Math.round((usuariosAtivos / totalUsuarios) * 100) : 0}%
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="usuarios" className="space-y-6">
          <TabsList>
            <TabsTrigger value="usuarios">Usuários</TabsTrigger>
            <TabsTrigger value="planos">Planos</TabsTrigger>
          </TabsList>

          <TabsContent value="usuarios">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>Usuários Cadastrados</CardTitle>
                    <CardDescription>
                      Gerencie todos os usuários da plataforma
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Search className="h-4 w-4" />
                    <Input
                      placeholder="Buscar usuários..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-64"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Nome</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Empresa</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Plano</TableHead>
                      <TableHead>Cadastro</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredUsuarios.map((usuario) => (
                      <TableRow key={usuario.id}>
                        <TableCell className="font-medium">
                          {usuario.nome}
                          {usuario.is_admin && (
                            <Badge className="ml-2" variant="secondary">Admin</Badge>
                          )}
                        </TableCell>
                        <TableCell>{usuario.email}</TableCell>
                        <TableCell>{usuario.empresa_nome || '-'}</TableCell>
                        <TableCell>
                          {usuario.subscriber ? 
                            getStatusBadge(usuario.subscriber.status) : 
                            <Badge variant="outline">Sem dados</Badge>
                          }
                        </TableCell>
                        <TableCell>
                          {usuario.subscriber?.subscription_tier || 'Trial'}
                        </TableCell>
                        <TableCell>
                          {new Date(usuario.created_at).toLocaleDateString('pt-BR')}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="planos">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Criar Novo Plano</CardTitle>
                  <CardDescription>
                    Adicione um novo plano de assinatura
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleCreatePlan} className="space-y-4">
                    <div>
                      <Label htmlFor="nome">Nome do Plano</Label>
                      <Input
                        id="nome"
                        value={newPlan.nome}
                        onChange={(e) => setNewPlan({...newPlan, nome: e.target.value})}
                        placeholder="Ex: Premium"
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="descricao">Descrição</Label>
                      <Input
                        id="descricao"
                        value={newPlan.descricao}
                        onChange={(e) => setNewPlan({...newPlan, descricao: e.target.value})}
                        placeholder="Descrição do plano"
                      />
                    </div>
                    <div>
                      <Label htmlFor="preco">Preço Mensal (R$)</Label>
                      <Input
                        id="preco"
                        type="number"
                        step="0.01"
                        min="0"
                        value={newPlan.preco_mensal}
                        onChange={(e) => setNewPlan({...newPlan, preco_mensal: parseFloat(e.target.value) || 0})}
                        placeholder="0.00"
                      />
                    </div>
                    <Button type="submit" className="w-full">
                      Criar Plano
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Planos Existentes</CardTitle>
                  <CardDescription>
                    Gerencie os planos disponíveis
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {planos.map((plano) => (
                      <div key={plano.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <div className="font-medium">{plano.nome}</div>
                          <div className="text-sm text-muted-foreground">
                            R$ {plano.preco_mensal.toFixed(2).replace('.', ',')}/mês
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={plano.ativo ? "default" : "secondary"}>
                            {plano.ativo ? "Ativo" : "Inativo"}
                          </Badge>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => togglePlanStatus(plano.id, plano.ativo)}
                          >
                            {plano.ativo ? "Desativar" : "Ativar"}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;