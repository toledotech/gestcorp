import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown,
  CreditCard,
  Banknote,
  ArrowUpRight,
  ArrowDownRight,
  Calendar,
  Filter
} from "lucide-react";

const DashboardFinanceiro = () => {
  const financialStats = [
    {
      title: "Saldo Total",
      value: "R$ 127.450,00",
      change: "+15.2%",
      trend: "up" as const,
      icon: DollarSign,
      color: "text-success"
    },
    {
      title: "A Receber (30d)",
      value: "R$ 45.200,00",
      change: "12 títulos",
      trend: "neutral" as const,
      icon: TrendingUp,
      color: "text-primary"
    },
    {
      title: "A Pagar (30d)",
      value: "R$ 28.750,00",
      change: "8 títulos",
      trend: "neutral" as const,
      icon: TrendingDown,
      color: "text-destructive"
    },
    {
      title: "Fluxo Líquido",
      value: "R$ 16.450,00",
      change: "+8.4%",
      trend: "up" as const,
      icon: Banknote,
      color: "text-success"
    }
  ];

  const contasReceber = [
    { cliente: "Empresa ABC Ltda", vencimento: "2024-01-15", valor: "R$ 5.500,00", status: "vencido" },
    { cliente: "XYZ Incorporadora", vencimento: "2024-01-20", valor: "R$ 8.200,00", status: "a_vencer" },
    { cliente: "Construtora Delta", vencimento: "2024-01-25", valor: "R$ 3.800,00", status: "a_vencer" },
    { cliente: "Imobiliária Prime", vencimento: "2024-01-30", valor: "R$ 6.100,00", status: "a_vencer" },
  ];

  const contasPagar = [
    { fornecedor: "Escritório Contábil", vencimento: "2024-01-18", valor: "R$ 2.500,00", status: "a_vencer" },
    { fornecedor: "Combustível e Manutenção", vencimento: "2024-01-22", valor: "R$ 1.800,00", status: "a_vencer" },
    { fornecedor: "Software e Licenças", vencimento: "2024-01-28", valor: "R$ 890,00", status: "a_vencer" },
    { fornecedor: "Aluguel Escritório", vencimento: "2024-02-01", valor: "R$ 4.200,00", status: "a_vencer" },
  ];

  const fluxoProjecoes = [
    { periodo: "Semana 1", entradas: 12500, saidas: 8300, liquido: 4200 },
    { periodo: "Semana 2", entradas: 15800, saidas: 6700, liquido: 9100 },
    { periodo: "Semana 3", entradas: 9200, saidas: 11400, liquido: -2200 },
    { periodo: "Semana 4", entradas: 18600, saidas: 7800, liquido: 10800 },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "vencido":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Vencido</Badge>;
      case "a_vencer":
        return <Badge className="bg-warning/10 text-warning border-warning/20">A Vencer</Badge>;
      case "liquidado":
        return <Badge className="bg-success/10 text-success border-success/20">Liquidado</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Dashboard Financeiro
          </h1>
          <p className="text-muted-foreground mt-1">
            Controle completo das finanças da empresa
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Filter className="h-4 w-4" />
            Filtros
          </Button>
          <Button variant="outline" className="gap-2">
            <Calendar className="h-4 w-4" />
            Período
          </Button>
        </div>
      </div>

      {/* Financial Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {financialStats.map((stat, index) => (
          <Card key={index} className="bg-gradient-card shadow-card border-0">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                <span className={stat.trend === "up" ? "text-success" : "text-muted-foreground"}>
                  {stat.change}
                </span>
                {" "}este mês
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Fluxo de Caixa Projetado */}
        <div className="lg:col-span-2">
          <Card className="bg-gradient-card shadow-card border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Fluxo de Caixa Projetado
              </CardTitle>
              <CardDescription>
                Projeção de entradas e saídas para as próximas semanas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {fluxoProjecoes.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-4 rounded-lg bg-muted/30">
                    <div>
                      <p className="font-medium">{item.periodo}</p>
                      <div className="flex gap-4 text-sm text-muted-foreground mt-1">
                        <span className="flex items-center gap-1">
                          <ArrowUpRight className="h-3 w-3 text-success" />
                          R$ {item.entradas.toLocaleString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <ArrowDownRight className="h-3 w-3 text-destructive" />
                          R$ {item.saidas.toLocaleString()}
                        </span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`font-bold ${item.liquido >= 0 ? 'text-success' : 'text-destructive'}`}>
                        R$ {Math.abs(item.liquido).toLocaleString()}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {item.liquido >= 0 ? 'Positivo' : 'Negativo'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Contas */}
        <div>
          <Tabs defaultValue="receber" className="space-y-4">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="receber">A Receber</TabsTrigger>
              <TabsTrigger value="pagar">A Pagar</TabsTrigger>
            </TabsList>
            
            <TabsContent value="receber">
              <Card className="bg-gradient-card shadow-card border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-success" />
                    Contas a Receber
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {contasReceber.map((conta, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">{conta.cliente}</p>
                        <p className="text-xs text-muted-foreground">{conta.vencimento}</p>
                        {getStatusBadge(conta.status)}
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-success">{conta.valor}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="pagar">
              <Card className="bg-gradient-card shadow-card border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5 text-destructive" />
                    Contas a Pagar
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {contasPagar.map((conta, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-lg bg-muted/20">
                      <div className="space-y-1">
                        <p className="text-sm font-medium">{conta.fornecedor}</p>
                        <p className="text-xs text-muted-foreground">{conta.vencimento}</p>
                        {getStatusBadge(conta.status)}
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-destructive">{conta.valor}</p>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default DashboardFinanceiro;