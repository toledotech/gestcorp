import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { PlanoStatus } from "@/components/PlanoStatus";
import { 
  FileText, 
  Users, 
  Calendar, 
  TrendingUp, 
  Clock,
  CheckCircle2,
  AlertTriangle,
  DollarSign,
  Plus
} from "lucide-react";

const Dashboard = () => {
  const stats = [
    {
      title: "OS Ativas",
      value: "147",
      change: "+12%",
      trend: "up" as const,
      icon: FileText,
      color: "text-primary"
    },
    {
      title: "Vistoriadores",
      value: "23",
      change: "+2",
      trend: "up" as const,
      icon: Users,
      color: "text-secondary"
    },
    {
      title: "Hoje",
      value: "8",
      change: "agendadas",
      trend: "neutral" as const,
      icon: Calendar,
      color: "text-warning"
    },
    {
      title: "Receita Mês",
      value: "R$ 45.2K",
      change: "+18%",
      trend: "up" as const,
      icon: DollarSign,
      color: "text-success"
    }
  ];

  const recentOS = [
    { id: "OS-2024-001", cliente: "Empresa ABC Ltda", tipo: "Residencial", status: "em_execucao", vistoriador: "João Silva" },
    { id: "OS-2024-002", cliente: "XYZ Incorporadora", tipo: "Comercial", status: "agendada", vistoriador: "Maria Santos" },
    { id: "OS-2024-003", cliente: "Construtora Delta", tipo: "Industrial", status: "pendente_dados", vistoriador: "Pedro Costa" },
    { id: "OS-2024-004", cliente: "Imobiliária Prime", tipo: "Residencial", status: "concluida", vistoriador: "Ana Lima" },
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "em_execucao":
        return <Badge className="bg-primary/10 text-primary border-primary/20">Em Execução</Badge>;
      case "agendada":
        return <Badge className="bg-warning/10 text-warning border-warning/20">Agendada</Badge>;
      case "pendente_dados":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Pendente</Badge>;
      case "concluida":
        return <Badge className="bg-success/10 text-success border-success/20">Concluída</Badge>;
      default:
        return <Badge variant="outline">Desconhecido</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            Dashboard Operacional
          </h1>
          <p className="text-muted-foreground mt-1">
            Visão geral das operações e vistorias
          </p>
        </div>
        <Button variant="premium" className="shadow-elegant">
          <Plus className="mr-2 h-4 w-4" />
          Nova OS
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <PlanoStatus />
        
        {stats.map((stat, index) => (
          <Card key={index} className="bg-gradient-card shadow-card border-0">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                <span className={stat.trend === "up" ? "text-success" : "text-muted-foreground"}>
                  {stat.change}
                </span>
                {" "}em relação ao mês anterior
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Recent OS */}
        <div className="lg:col-span-2">
          <Card className="bg-gradient-card shadow-card border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                Ordens de Serviço Recentes
              </CardTitle>
              <CardDescription>
                Últimas OS criadas e seus status atuais
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOS.map((os) => (
                  <div key={os.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/30">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm font-medium">{os.id}</span>
                        {getStatusBadge(os.status)}
                      </div>
                      <p className="text-sm text-muted-foreground">{os.cliente}</p>
                      <p className="text-xs text-muted-foreground">Tipo: {os.tipo}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{os.vistoriador}</p>
                      <p className="text-xs text-muted-foreground">Responsável</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Side Cards */}
        <div className="space-y-6">
          {/* Performance */}
          <Card className="bg-gradient-card shadow-card border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-success" />
                Performance
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Conclusão no Prazo</span>
                  <span className="font-medium">87%</span>
                </div>
                <Progress value={87} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Satisfação Cliente</span>
                  <span className="font-medium">94%</span>
                </div>
                <Progress value={94} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Utilização Equipe</span>
                  <span className="font-medium">76%</span>
                </div>
                <Progress value={76} className="h-2" />
              </div>
            </CardContent>
          </Card>

          {/* Alerts */}
          <Card className="bg-gradient-card shadow-card border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-warning" />
                Alertas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-3 p-3 rounded-lg bg-warning/5 border border-warning/20">
                <Clock className="h-4 w-4 text-warning mt-0.5" />
                <div>
                  <p className="text-sm font-medium">OS Atrasadas</p>
                  <p className="text-xs text-muted-foreground">3 vistorias em atraso</p>
                </div>
              </div>
              <div className="flex items-start gap-3 p-3 rounded-lg bg-success/5 border border-success/20">
                <CheckCircle2 className="h-4 w-4 text-success mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Meta Atingida</p>
                  <p className="text-xs text-muted-foreground">Receita mensal 105%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;