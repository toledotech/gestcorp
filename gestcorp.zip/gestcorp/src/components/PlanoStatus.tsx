import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Crown, Calendar, Zap, ArrowRight } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

interface Subscriber {
  status: string;
  subscription_tier: string;
  trial_end: string;
  subscription_end: string;
}

export function PlanoStatus() {
  const [subscriber, setSubscriber] = useState<Subscriber | null>(null);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      loadSubscriber();
    }
  }, [user]);

  const loadSubscriber = async () => {
    try {
      const { data, error } = await supabase
        .from('subscribers')
        .select('status, subscription_tier, trial_end, subscription_end')
        .eq('user_id', user?.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setSubscriber(data);
    } catch (error) {
      console.error('Erro ao carregar assinatura:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusInfo = () => {
    if (!subscriber) return null;

    switch (subscriber.status) {
      case 'trial':
        const trialEnd = new Date(subscriber.trial_end);
        const daysLeft = Math.ceil((trialEnd.getTime() - Date.now()) / (1000 * 60 * 60 * 24));
        return {
          status: 'Trial Gratuito',
          description: `${daysLeft} dias restantes`,
          variant: 'outline' as const,
          color: 'text-blue-600',
          icon: <Zap className="h-4 w-4" />,
          showUpgrade: daysLeft <= 7
        };
      case 'active':
        return {
          status: `Plano ${subscriber.subscription_tier}`,
          description: 'Assinatura ativa',
          variant: 'default' as const,
          color: 'text-green-600',
          icon: <Crown className="h-4 w-4" />,
          showUpgrade: false
        };
      case 'past_due':
        return {
          status: 'Pagamento Pendente',
          description: 'Atualize seu método de pagamento',
          variant: 'destructive' as const,
          color: 'text-red-600',
          icon: <Calendar className="h-4 w-4" />,
          showUpgrade: true
        };
      case 'canceled':
        return {
          status: 'Assinatura Cancelada',
          description: 'Reative sua conta para continuar',
          variant: 'secondary' as const,
          color: 'text-gray-600',
          icon: <Calendar className="h-4 w-4" />,
          showUpgrade: true
        };
      default:
        return {
          status: 'Status desconhecido',
          description: subscriber.status,
          variant: 'outline' as const,
          color: 'text-gray-600',
          icon: <Calendar className="h-4 w-4" />,
          showUpgrade: false
        };
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="space-y-1.5">
              <div className="h-4 w-24 bg-muted animate-pulse rounded" />
              <div className="h-3 w-32 bg-muted animate-pulse rounded" />
            </div>
            <div className="h-8 w-8 bg-muted animate-pulse rounded-full" />
          </div>
        </CardHeader>
      </Card>
    );
  }

  const statusInfo = getStatusInfo();
  
  if (!statusInfo) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-sm font-medium">Plano</CardTitle>
              <CardDescription>Carregando...</CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="relative overflow-hidden">
      {subscriber?.status === 'active' && (
        <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-primary opacity-10 rounded-full -mr-8 -mt-8" />
      )}
      
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <CardTitle className="text-sm font-medium">Seu Plano</CardTitle>
              <Badge variant={statusInfo.variant}>
                {statusInfo.status}
              </Badge>
            </div>
            <CardDescription className={statusInfo.color}>
              {statusInfo.description}
            </CardDescription>
          </div>
          <div className={`p-2 rounded-full bg-muted ${statusInfo.color}`}>
            {statusInfo.icon}
          </div>
        </div>
      </CardHeader>
      
      {statusInfo.showUpgrade && (
        <CardContent className="pt-0">
          <Button 
            size="sm" 
            className="w-full" 
            onClick={() => navigate('/planos')}
          >
            Ver Planos
            <ArrowRight className="h-3 w-3 ml-1" />
          </Button>
        </CardContent>
      )}
    </Card>
  );
}