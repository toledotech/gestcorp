import { NavLink, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  FileText, 
  Calendar,
  Users,
  Building2,
  DollarSign,
  CreditCard,
  TrendingUp,
  BarChart3,
  Settings,
  CheckSquare,
  MapPin
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";

const menuItems = [
  {
    title: "Dashboard",
    items: [
      { title: "Visão Geral", url: "/", icon: LayoutDashboard },
      { title: "Financeiro", url: "/dashboard-financeiro", icon: DollarSign },
    ]
  },
  {
    title: "SaaS",
    items: [
      { title: "Planos", url: "/planos", icon: CreditCard },
      { title: "Admin", url: "/admin", icon: Settings },
    ]
  },
  {
    title: "Operação",
    items: [
      { title: "Ordens de Serviço", url: "/ordens-servico", icon: FileText },
      { title: "Agenda", url: "/agenda", icon: Calendar },
      { title: "Checklists", url: "/checklists", icon: CheckSquare },
      { title: "Execuções", url: "/execucoes", icon: MapPin },
    ]
  },
  {
    title: "Financeiro",
    items: [
      { title: "Contas a Receber", url: "/contas-receber", icon: TrendingUp },
      { title: "Contas a Pagar", url: "/contas-pagar", icon: CreditCard },
      { title: "Fluxo de Caixa", url: "/fluxo-caixa", icon: BarChart3 },
      { title: "Faturamento", url: "/faturamento", icon: DollarSign },
    ]
  },
  {
    title: "Cadastros",
    items: [
      { title: "Clientes", url: "/clientes", icon: Users },
      { title: "Empresas", url: "/empresas", icon: Building2 },
      { title: "Usuários", url: "/usuarios", icon: Users },
    ]
  }
];

export function AppSidebar() {
  const { open } = useSidebar();
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };
  
  const getNavClasses = (active: boolean) => {
    return active 
      ? "bg-primary text-primary-foreground font-medium shadow-sm" 
      : "hover:bg-accent/50 text-muted-foreground hover:text-foreground";
  };

  return (
    <Sidebar className={open ? "w-64" : "w-16"} collapsible="icon">
      <SidebarContent className="bg-gradient-card">
        <div className="p-4 border-b">
          {open && (
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                <FileText className="h-4 w-4 text-white" />
              </div>
              <div>
                <h2 className="font-semibold text-foreground">GestCorp</h2>
                <p className="text-xs text-muted-foreground">v1.0</p>
              </div>
            </div>
          )}
        </div>
        
        <div className="flex-1 overflow-auto py-4">
          {menuItems.map((group) => (
            <SidebarGroup key={group.title}>
              {open && (
                <SidebarGroupLabel className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                  {group.title}
                </SidebarGroupLabel>
              )}
              <SidebarGroupContent>
                <SidebarMenu>
                  {group.items.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton asChild>
                        <NavLink 
                          to={item.url} 
                          className={getNavClasses(isActive(item.url))}
                        >
                          <item.icon className="h-4 w-4" />
                          {open && <span className="ml-3">{item.title}</span>}
                        </NavLink>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          ))}
        </div>
        
        <div className="p-4 border-t">
          <SidebarMenuButton asChild>
            <NavLink 
              to="/configuracoes" 
              className={getNavClasses(isActive("/configuracoes"))}
            >
              <Settings className="h-4 w-4" />
              {open && <span className="ml-3">Configurações</span>}
            </NavLink>
          </SidebarMenuButton>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}