# Configuração do Stripe para GestCorp SaaS

## Pré-requisitos
1. Conta no Stripe criada (https://stripe.com)
2. Sistema GestCorp funcionando com autenticação

## Passo 1: Obter Chaves do Stripe
1. Acesse o Dashboard do Stripe
2. Vá em **Developers > API Keys**
3. Copie a **Secret Key** (começa com `sk_`)

## Passo 2: Configurar Valores dos Planos
1. No Dashboard do Stripe, vá em **Products**
2. Crie produtos para cada plano:
   - **Básico**: R$ 29,90/mês
   - **Enterprise**: R$ 99,90/mês
3. Anote os **Price IDs** criados

## Passo 3: Adicionar Secret no Supabase
1. No projeto Lovable, adicione a chave Stripe como secret
2. Nome do secret: `STRIPE_SECRET_KEY`
3. Valor: sua chave secreta do Stripe

## Passo 4: Atualizar Preços no Banco
Execute no SQL Editor do Supabase:

```sql
-- Atualizar preços dos planos
UPDATE public.planos 
SET preco_mensal = 29.90 
WHERE nome = 'Básico';

UPDATE public.planos 
SET preco_mensal = 99.90 
WHERE nome = 'Enterprise';
```

## Passo 5: Edge Functions Stripe (Criar quando pronto)
Será necessário criar as seguintes edge functions:

1. **create-checkout**: Criar sessão de pagamento
2. **check-subscription**: Verificar status da assinatura
3. **customer-portal**: Portal do cliente para gerenciar assinatura

## Passo 6: Testar Pagamentos
1. Use cartões de teste do Stripe
2. Verifique se assinaturas são criadas corretamente
3. Teste cancelamentos e renovações

## URLs de Redirecionamento
Configure no Stripe:
- **Success URL**: `https://seudominio.com/planos?success=true`
- **Cancel URL**: `https://seudominio.com/planos?canceled=true`

## Status Implementado ✅
- [x] Estrutura de banco de dados SaaS
- [x] Sistema de autenticação
- [x] Páginas de planos e admin
- [x] Políticas RLS de segurança
- [x] Interface para planos
- [x] Sistema de trials (14 dias)

## Próximos Passos 🚀
- [ ] Configurar conta Stripe
- [ ] Implementar edge functions de pagamento
- [ ] Testar fluxo completo de assinatura
- [ ] Configurar webhooks (opcional)
- [ ] Deploy em produção

## Observações Importantes
- O sistema já funciona em modo trial
- Usuários têm 14 dias para testar
- Interface está preparada para Stripe
- Banco de dados está estruturado para multi-tenant

Quando estiver pronto para implementar os pagamentos, me informe que eu implemento as edge functions do Stripe!