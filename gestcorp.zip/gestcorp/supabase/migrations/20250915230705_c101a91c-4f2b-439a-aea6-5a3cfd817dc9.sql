-- Remove tabela usuarios desnecessária que representa risco de segurança
-- Esta tabela não é usada pelo sistema, que já utiliza Supabase Auth + profiles

-- Primeiro, remover referências estrangeiras que apontam para esta tabela
ALTER TABLE anexos DROP CONSTRAINT IF EXISTS anexos_usuario_id_fkey;
ALTER TABLE execucoes_checklist DROP CONSTRAINT IF EXISTS execucoes_checklist_usuario_id_fkey;
ALTER TABLE fotos DROP CONSTRAINT IF EXISTS fotos_usuario_id_fkey;
ALTER TABLE historicos DROP CONSTRAINT IF EXISTS historicos_usuario_id_fkey;
ALTER TABLE ordens_servico DROP CONSTRAINT IF EXISTS ordens_servico_responsavel_id_fkey;

-- Atualizar as tabelas para referenciar auth.users diretamente ou usar profiles
-- Para anexos: manter usuario_id mas sem foreign key (será validado via RLS)
-- Para execucoes_checklist: manter usuario_id mas sem foreign key (será validado via RLS)  
-- Para fotos: manter usuario_id mas sem foreign key (será validado via RLS)
-- Para historicos: manter usuario_id mas sem foreign key (será validado via RLS)
-- Para ordens_servico: responsavel_id pode referenciar profiles

-- Adicionar foreign key para ordens_servico.responsavel_id -> profiles.user_id
ALTER TABLE ordens_servico 
ADD CONSTRAINT ordens_servico_responsavel_id_fkey 
FOREIGN KEY (responsavel_id) REFERENCES profiles(user_id);

-- Remover a tabela usuarios completamente
DROP TABLE IF EXISTS public.usuarios CASCADE;