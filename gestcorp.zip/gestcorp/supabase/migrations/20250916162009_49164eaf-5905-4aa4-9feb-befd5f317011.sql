-- Corrigir políticas RLS vulneráveis da tabela empresas
-- Remover as políticas permissivas atuais
DROP POLICY "Usuários podem ver suas empresas" ON public.empresas;
DROP POLICY "Usuários podem atualizar suas empresas" ON public.empresas;
DROP POLICY "Usuários autenticados podem criar empresas" ON public.empresas;

-- Criar políticas seguras que restringem acesso apenas às empresas do usuário
CREATE POLICY "Usuários podem ver apenas suas empresas" 
ON public.empresas 
FOR SELECT 
USING (id = ANY (get_user_empresa_access(auth.uid())));

CREATE POLICY "Usuários podem atualizar apenas suas empresas" 
ON public.empresas 
FOR UPDATE 
USING (id = ANY (get_user_empresa_access(auth.uid())));

CREATE POLICY "Usuários podem criar empresas quando autenticados" 
ON public.empresas 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

-- Corrigir políticas das tabelas tipos_vistoria e checklists_modelo
-- para serem específicas por empresa (assumindo que precisam ser globais por agora, mas com restrições)

-- Para tipos_vistoria: permitir apenas leitura para usuários autenticados
-- e criação/edição apenas para admins
DROP POLICY "Usuários autenticados podem ver tipos de vistoria" ON public.tipos_vistoria;
DROP POLICY "Usuários autenticados podem criar tipos de vistoria" ON public.tipos_vistoria;  
DROP POLICY "Usuários autenticados podem atualizar tipos de vistoria" ON public.tipos_vistoria;

CREATE POLICY "Usuários podem ver tipos de vistoria" 
ON public.tipos_vistoria 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Apenas admins podem criar tipos de vistoria" 
ON public.tipos_vistoria 
FOR INSERT 
WITH CHECK (EXISTS (
    SELECT 1 FROM profiles 
    WHERE user_id = auth.uid() AND is_admin = true
));

CREATE POLICY "Apenas admins podem atualizar tipos de vistoria" 
ON public.tipos_vistoria 
FOR UPDATE 
USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE user_id = auth.uid() AND is_admin = true
));

-- Para checklists_modelo: mesma lógica
DROP POLICY "Usuários autenticados podem ver checklists modelo" ON public.checklists_modelo;
DROP POLICY "Usuários autenticados podem criar checklists modelo" ON public.checklists_modelo;
DROP POLICY "Usuários autenticados podem atualizar checklists modelo" ON public.checklists_modelo;

CREATE POLICY "Usuários podem ver checklists modelo" 
ON public.checklists_modelo 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Apenas admins podem criar checklists modelo" 
ON public.checklists_modelo 
FOR INSERT 
WITH CHECK (EXISTS (
    SELECT 1 FROM profiles 
    WHERE user_id = auth.uid() AND is_admin = true
));

CREATE POLICY "Apenas admins podem atualizar checklists modelo" 
ON public.checklists_modelo 
FOR UPDATE 
USING (EXISTS (
    SELECT 1 FROM profiles 
    WHERE user_id = auth.uid() AND is_admin = true
));