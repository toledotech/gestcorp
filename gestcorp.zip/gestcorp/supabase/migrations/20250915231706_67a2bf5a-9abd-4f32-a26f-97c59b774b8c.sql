-- Corrigir função sem dropar - usando aliases para evitar ambiguidade
CREATE OR REPLACE FUNCTION public.get_user_empresa_access(user_id uuid)
RETURNS uuid[]
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
    -- Retornar empresas às quais o usuário tem acesso através dos tenants
    -- Usando aliases para evitar ambiguidade
    RETURN ARRAY(
        SELECT DISTINCT t.empresa_id 
        FROM tenants t
        LEFT JOIN tenant_members tm ON t.id = tm.tenant_id
        WHERE t.owner_id = get_user_empresa_access.user_id 
           OR tm.user_id = get_user_empresa_access.user_id
    );
END;
$function$;