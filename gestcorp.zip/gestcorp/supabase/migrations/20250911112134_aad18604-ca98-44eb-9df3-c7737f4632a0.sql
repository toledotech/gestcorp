-- Criar tabela de perfis de usuário (profiles)
CREATE TABLE public.profiles (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
    nome TEXT NOT NULL,
    email TEXT NOT NULL,
    empresa_nome TEXT,
    cnpj TEXT,
    telefone TEXT,
    avatar_url TEXT,
    is_admin BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de planos SaaS
CREATE TABLE public.planos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    nome TEXT NOT NULL, -- 'Básico', 'Enterprise'
    descricao TEXT,
    preco_mensal DECIMAL(10,2) NOT NULL DEFAULT 0,
    limite_usuarios INTEGER,
    limite_empresas INTEGER,
    limite_os_mes INTEGER,
    modulos_incluidos TEXT[], -- Array com módulos disponíveis
    ativo BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de subscribers (assinantes)
CREATE TABLE public.subscribers (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
    email TEXT NOT NULL UNIQUE,
    stripe_customer_id TEXT UNIQUE,
    plano_id UUID REFERENCES public.planos(id),
    subscribed BOOLEAN NOT NULL DEFAULT false,
    subscription_tier TEXT, -- 'Básico', 'Enterprise'
    subscription_end TIMESTAMP WITH TIME ZONE,
    trial_end TIMESTAMP WITH TIME ZONE,
    status TEXT NOT NULL DEFAULT 'trial', -- 'trial', 'active', 'past_due', 'canceled'
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de tenant (empresas no modelo SaaS)
CREATE TABLE public.tenants (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    owner_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    empresa_id UUID REFERENCES public.empresas(id) ON DELETE CASCADE NOT NULL,
    plano_id UUID REFERENCES public.planos(id),
    ativo BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de membros dos tenants
CREATE TABLE public.tenant_members (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    tenant_id UUID REFERENCES public.tenants(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role TEXT NOT NULL DEFAULT 'member', -- 'owner', 'admin', 'member'
    invited_by UUID REFERENCES auth.users(id),
    invited_at TIMESTAMP WITH TIME ZONE,
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(tenant_id, user_id)
);

-- Inserir planos padrão
INSERT INTO public.planos (nome, descricao, preco_mensal, modulos_incluidos) VALUES 
('Básico', 'Plano básico com funcionalidades essenciais', 0.00, ARRAY['dashboard', 'operacao', 'relatorios']),
('Enterprise', 'Plano completo com todos os recursos', 0.00, ARRAY['dashboard', 'operacao', 'financeiro', 'relatorios', 'admin']);

-- Habilitar RLS
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.planos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscribers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenant_members ENABLE ROW LEVEL SECURITY;

-- Políticas para profiles
CREATE POLICY "Usuários podem ver próprio perfil" ON public.profiles FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Usuários podem atualizar próprio perfil" ON public.profiles FOR UPDATE USING (user_id = auth.uid());
CREATE POLICY "Usuários podem inserir próprio perfil" ON public.profiles FOR INSERT WITH CHECK (user_id = auth.uid());

-- Políticas para planos (todos podem ver)
CREATE POLICY "Todos podem ver planos" ON public.planos FOR SELECT USING (ativo = true);

-- Políticas para subscribers
CREATE POLICY "Usuários podem ver própria assinatura" ON public.subscribers FOR SELECT USING (user_id = auth.uid() OR email = auth.email());
CREATE POLICY "Edge functions podem gerenciar assinaturas" ON public.subscribers FOR ALL USING (true);

-- Políticas para tenants
CREATE POLICY "Owners podem ver seus tenants" ON public.tenants FOR SELECT USING (owner_id = auth.uid());
CREATE POLICY "Owners podem gerenciar seus tenants" ON public.tenants FOR ALL USING (owner_id = auth.uid());

-- Políticas para tenant_members
CREATE POLICY "Membros podem ver próprio tenant" ON public.tenant_members FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Owners podem gerenciar membros" ON public.tenant_members FOR ALL USING (
    EXISTS (SELECT 1 FROM public.tenants WHERE id = tenant_id AND owner_id = auth.uid())
);

-- Criar triggers para updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_planos_updated_at BEFORE UPDATE ON public.planos FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_subscribers_updated_at BEFORE UPDATE ON public.subscribers FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Função para criar perfil automaticamente após registro
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO public.profiles (user_id, nome, email, empresa_nome, cnpj)
    VALUES (
        NEW.id,
        COALESCE(NEW.raw_user_meta_data ->> 'nome', 'Usuário'),
        NEW.email,
        NEW.raw_user_meta_data ->> 'empresa',
        NEW.raw_user_meta_data ->> 'cnpj'
    );
    
    -- Criar subscriber com trial
    INSERT INTO public.subscribers (user_id, email, status, trial_end)
    VALUES (
        NEW.id,
        NEW.email,
        'trial',
        now() + interval '14 days'
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger para criar perfil automaticamente
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();