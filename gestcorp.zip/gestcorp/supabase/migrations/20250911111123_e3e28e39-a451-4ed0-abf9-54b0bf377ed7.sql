-- Corrigir função para atualizar timestamps com search_path seguro
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Criar função auxiliar para verificar acesso do usuário
CREATE OR REPLACE FUNCTION public.get_user_empresa_access(user_id UUID)
RETURNS UUID[] AS $$
BEGIN
    -- Por enquanto retorna todas as empresas para testes
    -- Futuramente será baseado em permissões do usuário
    RETURN ARRAY(SELECT id FROM public.empresas);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- POLÍTICAS RLS PARA TABELAS PRINCIPAIS

-- Políticas para usuarios
CREATE POLICY "Usuários podem ver próprio perfil"
    ON public.usuarios FOR SELECT
    USING (id = auth.uid()::uuid);

CREATE POLICY "Admins podem ver todos usuários"
    ON public.usuarios FOR SELECT
    USING (true); -- Será refinado com autenticação

-- Políticas para empresas
CREATE POLICY "Usuários podem ver suas empresas"
    ON public.empresas FOR SELECT
    USING (true); -- Permite leitura para todos por enquanto

CREATE POLICY "Usuários autenticados podem criar empresas"
    ON public.empresas FOR INSERT
    WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Usuários podem atualizar suas empresas"
    ON public.empresas FOR UPDATE
    USING (true); -- Será refinado

-- Políticas para clientes
CREATE POLICY "Usuários podem ver clientes de suas empresas"
    ON public.clientes FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar clientes em suas empresas"
    ON public.clientes FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar clientes de suas empresas"
    ON public.clientes FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para fornecedores
CREATE POLICY "Usuários podem ver fornecedores de suas empresas"
    ON public.fornecedores FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar fornecedores em suas empresas"
    ON public.fornecedores FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar fornecedores de suas empresas"
    ON public.fornecedores FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para tipos_vistoria
CREATE POLICY "Usuários autenticados podem ver tipos de vistoria"
    ON public.tipos_vistoria FOR SELECT
    USING (auth.uid() IS NOT NULL);

CREATE POLICY "Usuários autenticados podem criar tipos de vistoria"
    ON public.tipos_vistoria FOR INSERT
    WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Usuários autenticados podem atualizar tipos de vistoria"
    ON public.tipos_vistoria FOR UPDATE
    USING (auth.uid() IS NOT NULL);

-- Políticas para checklists_modelo
CREATE POLICY "Usuários autenticados podem ver checklists modelo"
    ON public.checklists_modelo FOR SELECT
    USING (auth.uid() IS NOT NULL);

CREATE POLICY "Usuários autenticados podem criar checklists modelo"
    ON public.checklists_modelo FOR INSERT
    WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Usuários autenticados podem atualizar checklists modelo"
    ON public.checklists_modelo FOR UPDATE
    USING (auth.uid() IS NOT NULL);

-- Políticas para ordens_servico
CREATE POLICY "Usuários podem ver OS de suas empresas"
    ON public.ordens_servico FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar OS em suas empresas"
    ON public.ordens_servico FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar OS de suas empresas"
    ON public.ordens_servico FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para locais_vistoria
CREATE POLICY "Usuários podem ver locais de vistoria de suas OS"
    ON public.locais_vistoria FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.ordens_servico os 
        WHERE os.id = ordem_servico_id 
        AND os.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

CREATE POLICY "Usuários podem criar locais de vistoria em suas OS"
    ON public.locais_vistoria FOR INSERT
    WITH CHECK (EXISTS (
        SELECT 1 FROM public.ordens_servico os 
        WHERE os.id = ordem_servico_id 
        AND os.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

-- Políticas para execucoes_checklist
CREATE POLICY "Usuários podem ver execuções de suas OS"
    ON public.execucoes_checklist FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.ordens_servico os 
        WHERE os.id = ordem_servico_id 
        AND os.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

CREATE POLICY "Usuários podem criar execuções em suas OS"
    ON public.execucoes_checklist FOR INSERT
    WITH CHECK (usuario_id = auth.uid()::uuid);

CREATE POLICY "Usuários podem atualizar suas execuções"
    ON public.execucoes_checklist FOR UPDATE
    USING (usuario_id = auth.uid()::uuid);

-- Políticas para respostas_checklist
CREATE POLICY "Usuários podem ver respostas de suas execuções"
    ON public.respostas_checklist FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.execucoes_checklist ec
        WHERE ec.id = execucao_id 
        AND ec.usuario_id = auth.uid()::uuid
    ));

CREATE POLICY "Usuários podem criar respostas em suas execuções"
    ON public.respostas_checklist FOR INSERT
    WITH CHECK (EXISTS (
        SELECT 1 FROM public.execucoes_checklist ec
        WHERE ec.id = execucao_id 
        AND ec.usuario_id = auth.uid()::uuid
    ));

-- Políticas para anexos
CREATE POLICY "Usuários podem ver seus anexos"
    ON public.anexos FOR SELECT
    USING (usuario_id = auth.uid()::uuid);

CREATE POLICY "Usuários podem criar anexos"
    ON public.anexos FOR INSERT
    WITH CHECK (usuario_id = auth.uid()::uuid);

-- Políticas para fotos
CREATE POLICY "Usuários podem ver suas fotos"
    ON public.fotos FOR SELECT
    USING (usuario_id = auth.uid()::uuid);

CREATE POLICY "Usuários podem criar fotos"
    ON public.fotos FOR INSERT
    WITH CHECK (usuario_id = auth.uid()::uuid);

-- Políticas para historicos
CREATE POLICY "Usuários podem ver seus históricos"
    ON public.historicos FOR SELECT
    USING (usuario_id = auth.uid()::uuid);

CREATE POLICY "Usuários podem criar históricos"
    ON public.historicos FOR INSERT
    WITH CHECK (usuario_id = auth.uid()::uuid);

-- POLÍTICAS FINANCEIRAS

-- Políticas para contas_bancarias
CREATE POLICY "Usuários podem ver contas bancárias de suas empresas"
    ON public.contas_bancarias FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar contas bancárias em suas empresas"
    ON public.contas_bancarias FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar contas bancárias de suas empresas"
    ON public.contas_bancarias FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para movimentos_bancarios
CREATE POLICY "Usuários podem ver movimentos de suas contas"
    ON public.movimentos_bancarios FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.contas_bancarias cb
        WHERE cb.id = conta_id 
        AND cb.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

CREATE POLICY "Usuários podem criar movimentos em suas contas"
    ON public.movimentos_bancarios FOR INSERT
    WITH CHECK (EXISTS (
        SELECT 1 FROM public.contas_bancarias cb
        WHERE cb.id = conta_id 
        AND cb.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

-- Políticas para centros_custos
CREATE POLICY "Usuários podem ver centros de custos de suas empresas"
    ON public.centros_custos FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar centros de custos em suas empresas"
    ON public.centros_custos FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para categorias_financeiras
CREATE POLICY "Usuários podem ver categorias financeiras de suas empresas"
    ON public.categorias_financeiras FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar categorias financeiras em suas empresas"
    ON public.categorias_financeiras FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para contas_receber
CREATE POLICY "Usuários podem ver contas a receber de suas empresas"
    ON public.contas_receber FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar contas a receber em suas empresas"
    ON public.contas_receber FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar contas a receber de suas empresas"
    ON public.contas_receber FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para recebimentos
CREATE POLICY "Usuários podem ver recebimentos de suas contas"
    ON public.recebimentos FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.contas_receber cr
        WHERE cr.id = conta_receber_id 
        AND cr.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

CREATE POLICY "Usuários podem criar recebimentos em suas contas"
    ON public.recebimentos FOR INSERT
    WITH CHECK (EXISTS (
        SELECT 1 FROM public.contas_receber cr
        WHERE cr.id = conta_receber_id 
        AND cr.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

-- Políticas para contas_pagar
CREATE POLICY "Usuários podem ver contas a pagar de suas empresas"
    ON public.contas_pagar FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar contas a pagar em suas empresas"
    ON public.contas_pagar FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar contas a pagar de suas empresas"
    ON public.contas_pagar FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para pagamentos
CREATE POLICY "Usuários podem ver pagamentos de suas contas"
    ON public.pagamentos FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.contas_pagar cp
        WHERE cp.id = conta_pagar_id 
        AND cp.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

CREATE POLICY "Usuários podem criar pagamentos em suas contas"
    ON public.pagamentos FOR INSERT
    WITH CHECK (EXISTS (
        SELECT 1 FROM public.contas_pagar cp
        WHERE cp.id = conta_pagar_id 
        AND cp.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

-- Políticas para produtos_servicos
CREATE POLICY "Usuários podem ver produtos/serviços de suas empresas"
    ON public.produtos_servicos FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar produtos/serviços em suas empresas"
    ON public.produtos_servicos FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar produtos/serviços de suas empresas"
    ON public.produtos_servicos FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para compras
CREATE POLICY "Usuários podem ver compras de suas empresas"
    ON public.compras FOR SELECT
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem criar compras em suas empresas"
    ON public.compras FOR INSERT
    WITH CHECK (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

CREATE POLICY "Usuários podem atualizar compras de suas empresas"
    ON public.compras FOR UPDATE
    USING (empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid)));

-- Políticas para compras_itens
CREATE POLICY "Usuários podem ver itens de suas compras"
    ON public.compras_itens FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.compras c
        WHERE c.id = compra_id 
        AND c.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

CREATE POLICY "Usuários podem criar itens em suas compras"
    ON public.compras_itens FOR INSERT
    WITH CHECK (EXISTS (
        SELECT 1 FROM public.compras c
        WHERE c.id = compra_id 
        AND c.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

-- Políticas para faturamentos
CREATE POLICY "Usuários podem ver faturamentos de suas OS"
    ON public.faturamentos FOR SELECT
    USING (EXISTS (
        SELECT 1 FROM public.ordens_servico os
        WHERE os.id = os_id 
        AND os.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));

CREATE POLICY "Usuários podem criar faturamentos em suas OS"
    ON public.faturamentos FOR INSERT
    WITH CHECK (EXISTS (
        SELECT 1 FROM public.ordens_servico os
        WHERE os.id = os_id 
        AND os.empresa_id = ANY(public.get_user_empresa_access(auth.uid()::uuid))
    ));