-- Fix remaining security issues - handle existing policies properly

-- Drop ALL existing policies on usuarios table first
DO $$ 
DECLARE
    pol record;
BEGIN
    FOR pol IN 
        SELECT schemaname, tablename, policyname 
        FROM pg_policies 
        WHERE schemaname = 'public' AND tablename = 'usuarios'
    LOOP
        EXECUTE format('DROP POLICY IF EXISTS %I ON %I.%I', pol.policyname, pol.schemaname, pol.tablename);
    END LOOP;
END $$;

-- Create secure policies for usuarios table
CREATE POLICY "Usuários podem ver próprios dados" 
ON public.usuarios 
FOR SELECT 
USING (auth.uid() = id);

CREATE POLICY "Usuários podem atualizar próprios dados" 
ON public.usuarios 
FOR UPDATE 
USING (auth.uid() = id);

-- Fix subscribers edge function policy - make it more specific to authenticated edge functions only
DROP POLICY IF EXISTS "Edge functions podem gerenciar assinaturas" ON public.subscribers;

-- Create more secure edge function access policy
CREATE POLICY "Edge functions autenticadas podem gerenciar assinaturas" 
ON public.subscribers 
FOR ALL 
USING (auth.role() = 'service_role');