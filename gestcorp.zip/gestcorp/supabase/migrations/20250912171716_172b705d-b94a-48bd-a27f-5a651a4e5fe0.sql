-- Remove overly permissive RLS policies that allow unrestricted access
-- These policies bypass the proper company-scoped security controls

-- Remove permissive policies for anexos table
DROP POLICY IF EXISTS "anexos_insert_policy" ON public.anexos;
DROP POLICY IF EXISTS "anexos_select_policy" ON public.anexos;

-- Remove permissive policies for categorias_financeiras table
DROP POLICY IF EXISTS "categorias_financeiras_insert_policy" ON public.categorias_financeiras;
DROP POLICY IF EXISTS "categorias_financeiras_select_policy" ON public.categorias_financeiras;
DROP POLICY IF EXISTS "categorias_financeiras_update_policy" ON public.categorias_financeiras;

-- Remove permissive policies for centros_custos table
DROP POLICY IF EXISTS "centros_custos_insert_policy" ON public.centros_custos;
DROP POLICY IF EXISTS "centros_custos_select_policy" ON public.centros_custos;
DROP POLICY IF EXISTS "centros_custos_update_policy" ON public.centros_custos;

-- Remove permissive policies for checklists_modelo table
DROP POLICY IF EXISTS "checklists_modelo_insert_policy" ON public.checklists_modelo;
DROP POLICY IF EXISTS "checklists_modelo_select_policy" ON public.checklists_modelo;
DROP POLICY IF EXISTS "checklists_modelo_update_policy" ON public.checklists_modelo;

-- Remove permissive policies for clientes table
DROP POLICY IF EXISTS "clientes_insert_policy" ON public.clientes;
DROP POLICY IF EXISTS "clientes_select_policy" ON public.clientes;
DROP POLICY IF EXISTS "clientes_update_policy" ON public.clientes;

-- Remove permissive policies for compras table
DROP POLICY IF EXISTS "compras_insert_policy" ON public.compras;
DROP POLICY IF EXISTS "compras_select_policy" ON public.compras;
DROP POLICY IF EXISTS "compras_update_policy" ON public.compras;

-- Remove permissive policies for compras_itens table
DROP POLICY IF EXISTS "compras_itens_insert_policy" ON public.compras_itens;
DROP POLICY IF EXISTS "compras_itens_select_policy" ON public.compras_itens;
DROP POLICY IF EXISTS "compras_itens_update_policy" ON public.compras_itens;

-- Remove permissive policies for contas_bancarias table
DROP POLICY IF EXISTS "contas_bancarias_insert_policy" ON public.contas_bancarias;
DROP POLICY IF EXISTS "contas_bancarias_select_policy" ON public.contas_bancarias;
DROP POLICY IF EXISTS "contas_bancarias_update_policy" ON public.contas_bancarias;

-- Remove permissive policies for contas_pagar table
DROP POLICY IF EXISTS "contas_pagar_insert_policy" ON public.contas_pagar;
DROP POLICY IF EXISTS "contas_pagar_select_policy" ON public.contas_pagar;
DROP POLICY IF EXISTS "contas_pagar_update_policy" ON public.contas_pagar;

-- Remove permissive policies for contas_receber table
DROP POLICY IF EXISTS "contas_receber_insert_policy" ON public.contas_receber;
DROP POLICY IF EXISTS "contas_receber_select_policy" ON public.contas_receber;
DROP POLICY IF EXISTS "contas_receber_update_policy" ON public.contas_receber;

-- Remove permissive policies for empresas table
DROP POLICY IF EXISTS "empresas_insert_policy" ON public.empresas;
DROP POLICY IF EXISTS "empresas_select_policy" ON public.empresas;
DROP POLICY IF EXISTS "empresas_update_policy" ON public.empresas;

-- Remove permissive policies for execucoes_checklist table
DROP POLICY IF EXISTS "execucoes_checklist_insert_policy" ON public.execucoes_checklist;
DROP POLICY IF EXISTS "execucoes_checklist_select_policy" ON public.execucoes_checklist;
DROP POLICY IF EXISTS "execucoes_checklist_update_policy" ON public.execucoes_checklist;

-- Remove permissive policies for faturamentos table
DROP POLICY IF EXISTS "faturamentos_insert_policy" ON public.faturamentos;
DROP POLICY IF EXISTS "faturamentos_select_policy" ON public.faturamentos;
DROP POLICY IF EXISTS "faturamentos_update_policy" ON public.faturamentos;

-- Remove permissive policies for fornecedores table
DROP POLICY IF EXISTS "fornecedores_insert_policy" ON public.fornecedores;
DROP POLICY IF EXISTS "fornecedores_select_policy" ON public.fornecedores;
DROP POLICY IF EXISTS "fornecedores_update_policy" ON public.fornecedores;

-- Remove permissive policies for fotos table
DROP POLICY IF EXISTS "fotos_insert_policy" ON public.fotos;
DROP POLICY IF EXISTS "fotos_select_policy" ON public.fotos;

-- Remove permissive policies for historicos table
DROP POLICY IF EXISTS "historicos_insert_policy" ON public.historicos;
DROP POLICY IF EXISTS "historicos_select_policy" ON public.historicos;

-- Remove permissive policies for locais_vistoria table
DROP POLICY IF EXISTS "locais_vistoria_insert_policy" ON public.locais_vistoria;
DROP POLICY IF EXISTS "locais_vistoria_select_policy" ON public.locais_vistoria;
DROP POLICY IF EXISTS "locais_vistoria_update_policy" ON public.locais_vistoria;

-- Remove permissive policies for movimentos_bancarios table
DROP POLICY IF EXISTS "movimentos_bancarios_insert_policy" ON public.movimentos_bancarios;
DROP POLICY IF EXISTS "movimentos_bancarios_select_policy" ON public.movimentos_bancarios;
DROP POLICY IF EXISTS "movimentos_bancarios_update_policy" ON public.movimentos_bancarios;

-- Remove permissive policies for ordens_servico table
DROP POLICY IF EXISTS "ordens_servico_insert_policy" ON public.ordens_servico;
DROP POLICY IF EXISTS "ordens_servico_select_policy" ON public.ordens_servico;
DROP POLICY IF EXISTS "ordens_servico_update_policy" ON public.ordens_servico;

-- Remove permissive policies for pagamentos table
DROP POLICY IF EXISTS "pagamentos_insert_policy" ON public.pagamentos;
DROP POLICY IF EXISTS "pagamentos_select_policy" ON public.pagamentos;

-- Remove permissive policies for produtos_servicos table
DROP POLICY IF EXISTS "produtos_servicos_insert_policy" ON public.produtos_servicos;
DROP POLICY IF EXISTS "produtos_servicos_select_policy" ON public.produtos_servicos;
DROP POLICY IF EXISTS "produtos_servicos_update_policy" ON public.produtos_servicos;

-- Remove permissive policies for recebimentos table
DROP POLICY IF EXISTS "recebimentos_insert_policy" ON public.recebimentos;
DROP POLICY IF EXISTS "recebimentos_select_policy" ON public.recebimentos;

-- Remove permissive policies for respostas_checklist table
DROP POLICY IF EXISTS "respostas_checklist_insert_policy" ON public.respostas_checklist;
DROP POLICY IF EXISTS "respostas_checklist_select_policy" ON public.respostas_checklist;
DROP POLICY IF EXISTS "respostas_checklist_update_policy" ON public.respostas_checklist;

-- Remove permissive policies for tipos_vistoria table
DROP POLICY IF EXISTS "tipos_vistoria_insert_policy" ON public.tipos_vistoria;
DROP POLICY IF EXISTS "tipos_vistoria_select_policy" ON public.tipos_vistoria;
DROP POLICY IF EXISTS "tipos_vistoria_update_policy" ON public.tipos_vistoria;

-- Fix planos table access - restrict to authenticated users only
DROP POLICY IF EXISTS "Todos podem ver planos" ON public.planos;
CREATE POLICY "Usuários autenticados podem ver planos" 
ON public.planos 
FOR SELECT 
USING (auth.uid() IS NOT NULL AND ativo = true);