-- Create enum for user roles only if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
        CREATE TYPE public.user_role AS ENUM ('admin', 'manager', 'operator', 'viewer');
    END IF;
END $$;

-- Create user roles table to manage granular permissions if it doesn't exist
CREATE TABLE IF NOT EXISTS public.user_roles (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL,
    empresa_id UUID NOT NULL,
    role user_role NOT NULL DEFAULT 'viewer',
    permissions JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    created_by UUID,
    UNIQUE(user_id, empresa_id)
);

-- Enable RLS on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Users can view their own roles" ON public.user_roles;
DROP POLICY IF EXISTS "Admins and managers can manage roles in their companies" ON public.user_roles;

-- Create policies for user_roles table
CREATE POLICY "Users can view their own roles" 
ON public.user_roles 
FOR SELECT 
USING (user_id = auth.uid());

CREATE POLICY "Admins and managers can manage roles in their companies" 
ON public.user_roles 
FOR ALL 
USING (
    EXISTS (
        SELECT 1 FROM public.user_roles ur
        WHERE ur.user_id = auth.uid() 
        AND ur.empresa_id = user_roles.empresa_id 
        AND ur.role IN ('admin', 'manager')
    )
);

-- Create security definer function to check user role and permissions
CREATE OR REPLACE FUNCTION public.check_user_permission(
    _empresa_id UUID,
    _permission TEXT DEFAULT 'read_customers'
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    user_role_rec RECORD;
BEGIN
    -- Get user role for the specific company
    SELECT role, permissions INTO user_role_rec
    FROM public.user_roles
    WHERE user_id = auth.uid() AND empresa_id = _empresa_id;
    
    -- If user has no role in this company, deny access
    IF NOT FOUND THEN
        RETURN FALSE;
    END IF;
    
    -- Admin and manager roles have full access
    IF user_role_rec.role IN ('admin', 'manager') THEN
        RETURN TRUE;
    END IF;
    
    -- Check specific permissions for other roles
    IF user_role_rec.permissions ? _permission THEN
        RETURN (user_role_rec.permissions ->> _permission)::boolean;
    END IF;
    
    -- Default permissions based on role
    CASE user_role_rec.role
        WHEN 'operator' THEN
            RETURN _permission IN ('read_customers', 'create_customers', 'update_customers');
        WHEN 'viewer' THEN
            RETURN _permission = 'read_customers';
        ELSE
            RETURN FALSE;
    END CASE;
END;
$$;

-- Update RLS policies for clientes table with stricter access control
DROP POLICY IF EXISTS "Usuários podem ver clientes de suas empresas" ON public.clientes;
DROP POLICY IF EXISTS "Usuários podem criar clientes em suas empresas" ON public.clientes;
DROP POLICY IF EXISTS "Usuários podem atualizar clientes de suas empresas" ON public.clientes;

-- New stricter policies for clientes table
CREATE POLICY "Users can view customers with proper permissions" 
ON public.clientes 
FOR SELECT 
USING (
    check_user_permission(empresa_id, 'read_customers')
);

CREATE POLICY "Users can create customers with proper permissions" 
ON public.clientes 
FOR INSERT 
WITH CHECK (
    check_user_permission(empresa_id, 'create_customers')
);

CREATE POLICY "Users can update customers with proper permissions" 
ON public.clientes 
FOR UPDATE 
USING (
    check_user_permission(empresa_id, 'update_customers')
);

-- Create trigger to automatically update updated_at if it doesn't exist
DROP TRIGGER IF EXISTS update_user_roles_updated_at ON public.user_roles;
CREATE TRIGGER update_user_roles_updated_at
    BEFORE UPDATE ON public.user_roles
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default roles for existing users based on profiles
INSERT INTO public.user_roles (user_id, empresa_id, role, created_by)
SELECT DISTINCT 
    p.user_id,
    t.empresa_id,
    CASE 
        WHEN p.is_admin THEN 'admin'::user_role
        ELSE 'manager'::user_role
    END,
    p.user_id
FROM public.profiles p
JOIN public.tenants t ON t.owner_id = p.user_id
WHERE NOT EXISTS (
    SELECT 1 FROM public.user_roles ur 
    WHERE ur.user_id = p.user_id AND ur.empresa_id = t.empresa_id
)
ON CONFLICT (user_id, empresa_id) DO NOTHING;