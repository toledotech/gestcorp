-- Remover políticas existentes (caso existam)
DROP POLICY IF EXISTS "Usuários podem ver próprio perfil" ON public.usuarios;
DROP POLICY IF EXISTS "Admins podem ver todos usuários" ON public.usuarios;

-- Criar políticas básicas simplificadas para teste
CREATE POLICY "usuarios_select_policy" ON public.usuarios FOR SELECT USING (true);
CREATE POLICY "usuarios_insert_policy" ON public.usuarios FOR INSERT WITH CHECK (true);
CREATE POLICY "usuarios_update_policy" ON public.usuarios FOR UPDATE USING (true);

CREATE POLICY "empresas_select_policy" ON public.empresas FOR SELECT USING (true);
CREATE POLICY "empresas_insert_policy" ON public.empresas FOR INSERT WITH CHECK (true);
CREATE POLICY "empresas_update_policy" ON public.empresas FOR UPDATE USING (true);

CREATE POLICY "clientes_select_policy" ON public.clientes FOR SELECT USING (true);
CREATE POLICY "clientes_insert_policy" ON public.clientes FOR INSERT WITH CHECK (true);
CREATE POLICY "clientes_update_policy" ON public.clientes FOR UPDATE USING (true);

CREATE POLICY "fornecedores_select_policy" ON public.fornecedores FOR SELECT USING (true);
CREATE POLICY "fornecedores_insert_policy" ON public.fornecedores FOR INSERT WITH CHECK (true);
CREATE POLICY "fornecedores_update_policy" ON public.fornecedores FOR UPDATE USING (true);

CREATE POLICY "tipos_vistoria_select_policy" ON public.tipos_vistoria FOR SELECT USING (true);
CREATE POLICY "tipos_vistoria_insert_policy" ON public.tipos_vistoria FOR INSERT WITH CHECK (true);
CREATE POLICY "tipos_vistoria_update_policy" ON public.tipos_vistoria FOR UPDATE USING (true);

CREATE POLICY "checklists_modelo_select_policy" ON public.checklists_modelo FOR SELECT USING (true);
CREATE POLICY "checklists_modelo_insert_policy" ON public.checklists_modelo FOR INSERT WITH CHECK (true);
CREATE POLICY "checklists_modelo_update_policy" ON public.checklists_modelo FOR UPDATE USING (true);

CREATE POLICY "ordens_servico_select_policy" ON public.ordens_servico FOR SELECT USING (true);
CREATE POLICY "ordens_servico_insert_policy" ON public.ordens_servico FOR INSERT WITH CHECK (true);
CREATE POLICY "ordens_servico_update_policy" ON public.ordens_servico FOR UPDATE USING (true);

CREATE POLICY "locais_vistoria_select_policy" ON public.locais_vistoria FOR SELECT USING (true);
CREATE POLICY "locais_vistoria_insert_policy" ON public.locais_vistoria FOR INSERT WITH CHECK (true);
CREATE POLICY "locais_vistoria_update_policy" ON public.locais_vistoria FOR UPDATE USING (true);

CREATE POLICY "execucoes_checklist_select_policy" ON public.execucoes_checklist FOR SELECT USING (true);
CREATE POLICY "execucoes_checklist_insert_policy" ON public.execucoes_checklist FOR INSERT WITH CHECK (true);
CREATE POLICY "execucoes_checklist_update_policy" ON public.execucoes_checklist FOR UPDATE USING (true);

CREATE POLICY "respostas_checklist_select_policy" ON public.respostas_checklist FOR SELECT USING (true);
CREATE POLICY "respostas_checklist_insert_policy" ON public.respostas_checklist FOR INSERT WITH CHECK (true);
CREATE POLICY "respostas_checklist_update_policy" ON public.respostas_checklist FOR UPDATE USING (true);

CREATE POLICY "anexos_select_policy" ON public.anexos FOR SELECT USING (true);
CREATE POLICY "anexos_insert_policy" ON public.anexos FOR INSERT WITH CHECK (true);

CREATE POLICY "fotos_select_policy" ON public.fotos FOR SELECT USING (true);
CREATE POLICY "fotos_insert_policy" ON public.fotos FOR INSERT WITH CHECK (true);

CREATE POLICY "historicos_select_policy" ON public.historicos FOR SELECT USING (true);
CREATE POLICY "historicos_insert_policy" ON public.historicos FOR INSERT WITH CHECK (true);

CREATE POLICY "contas_bancarias_select_policy" ON public.contas_bancarias FOR SELECT USING (true);
CREATE POLICY "contas_bancarias_insert_policy" ON public.contas_bancarias FOR INSERT WITH CHECK (true);
CREATE POLICY "contas_bancarias_update_policy" ON public.contas_bancarias FOR UPDATE USING (true);

CREATE POLICY "movimentos_bancarios_select_policy" ON public.movimentos_bancarios FOR SELECT USING (true);
CREATE POLICY "movimentos_bancarios_insert_policy" ON public.movimentos_bancarios FOR INSERT WITH CHECK (true);
CREATE POLICY "movimentos_bancarios_update_policy" ON public.movimentos_bancarios FOR UPDATE USING (true);

CREATE POLICY "centros_custos_select_policy" ON public.centros_custos FOR SELECT USING (true);
CREATE POLICY "centros_custos_insert_policy" ON public.centros_custos FOR INSERT WITH CHECK (true);
CREATE POLICY "centros_custos_update_policy" ON public.centros_custos FOR UPDATE USING (true);

CREATE POLICY "categorias_financeiras_select_policy" ON public.categorias_financeiras FOR SELECT USING (true);
CREATE POLICY "categorias_financeiras_insert_policy" ON public.categorias_financeiras FOR INSERT WITH CHECK (true);
CREATE POLICY "categorias_financeiras_update_policy" ON public.categorias_financeiras FOR UPDATE USING (true);

CREATE POLICY "contas_receber_select_policy" ON public.contas_receber FOR SELECT USING (true);
CREATE POLICY "contas_receber_insert_policy" ON public.contas_receber FOR INSERT WITH CHECK (true);
CREATE POLICY "contas_receber_update_policy" ON public.contas_receber FOR UPDATE USING (true);

CREATE POLICY "recebimentos_select_policy" ON public.recebimentos FOR SELECT USING (true);
CREATE POLICY "recebimentos_insert_policy" ON public.recebimentos FOR INSERT WITH CHECK (true);

CREATE POLICY "contas_pagar_select_policy" ON public.contas_pagar FOR SELECT USING (true);
CREATE POLICY "contas_pagar_insert_policy" ON public.contas_pagar FOR INSERT WITH CHECK (true);
CREATE POLICY "contas_pagar_update_policy" ON public.contas_pagar FOR UPDATE USING (true);

CREATE POLICY "pagamentos_select_policy" ON public.pagamentos FOR SELECT USING (true);
CREATE POLICY "pagamentos_insert_policy" ON public.pagamentos FOR INSERT WITH CHECK (true);

CREATE POLICY "produtos_servicos_select_policy" ON public.produtos_servicos FOR SELECT USING (true);
CREATE POLICY "produtos_servicos_insert_policy" ON public.produtos_servicos FOR INSERT WITH CHECK (true);
CREATE POLICY "produtos_servicos_update_policy" ON public.produtos_servicos FOR UPDATE USING (true);

CREATE POLICY "compras_select_policy" ON public.compras FOR SELECT USING (true);
CREATE POLICY "compras_insert_policy" ON public.compras FOR INSERT WITH CHECK (true);
CREATE POLICY "compras_update_policy" ON public.compras FOR UPDATE USING (true);

CREATE POLICY "compras_itens_select_policy" ON public.compras_itens FOR SELECT USING (true);
CREATE POLICY "compras_itens_insert_policy" ON public.compras_itens FOR INSERT WITH CHECK (true);
CREATE POLICY "compras_itens_update_policy" ON public.compras_itens FOR UPDATE USING (true);

CREATE POLICY "faturamentos_select_policy" ON public.faturamentos FOR SELECT USING (true);
CREATE POLICY "faturamentos_insert_policy" ON public.faturamentos FOR INSERT WITH CHECK (true);
CREATE POLICY "faturamentos_update_policy" ON public.faturamentos FOR UPDATE USING (true);