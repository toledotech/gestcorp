-- Dropar e recriar função para corrigir ambiguidade
DROP FUNCTION IF EXISTS public.get_user_empresa_access(uuid);

CREATE OR REPLACE FUNCTION public.get_user_empresa_access(p_user_id uuid)
RETURNS uuid[]
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
    -- Retornar empresas às quais o usuário tem acesso através dos tenants
    RETURN ARRAY(
        SELECT DISTINCT t.empresa_id 
        FROM tenants t
        LEFT JOIN tenant_members tm ON t.id = tm.tenant_id
        WHERE t.owner_id = p_user_id 
           OR tm.user_id = p_user_id
    );
END;
$function$;