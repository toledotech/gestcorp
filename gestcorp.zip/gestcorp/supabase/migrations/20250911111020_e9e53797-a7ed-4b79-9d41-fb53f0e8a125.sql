-- Criar enums necessários
CREATE TYPE public.user_role AS ENUM ('admin', 'supervisor', 'usuario');
CREATE TYPE public.user_status AS ENUM ('ativo', 'inativo');
CREATE TYPE public.os_status AS ENUM ('rascunho', 'agendada', 'em_execucao', 'pendente_dados', 'concluida', 'cancelada');
CREATE TYPE public.os_prioridade AS ENUM ('baixa', 'media', 'alta');
CREATE TYPE public.execucao_status AS ENUM ('em_execucao', 'pendente_validacao', 'aprovado', 'reprovado');
CREATE TYPE public.resposta_tipo AS ENUM ('texto', 'numero', 'booleano', 'opcao', 'foto', 'anexo');
CREATE TYPE public.referencia_tipo AS ENUM ('os', 'execucao', 'financeiro');
CREATE TYPE public.movimento_tipo AS ENUM ('entrada', 'saida', 'transferencia');
CREATE TYPE public.origem_tipo AS ENUM ('receber', 'pagar', 'ajuste', 'transferencia');
CREATE TYPE public.categoria_tipo AS ENUM ('receita', 'despesa');
CREATE TYPE public.conta_status AS ENUM ('aberto', 'parcial', 'liquidado', 'cancelado');
CREATE TYPE public.forma_pagamento AS ENUM ('dinheiro', 'pix', 'transferencia', 'boleto', 'cartao', 'outro');
CREATE TYPE public.compra_status AS ENUM ('rascunho', 'aprovada', 'parcial', 'concluida', 'cancelada');
CREATE TYPE public.produto_tipo AS ENUM ('produto', 'servico');

-- Tabela de usuários
CREATE TABLE public.usuarios (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    nome TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    senha_hash TEXT,
    papel user_role NOT NULL DEFAULT 'usuario',
    status user_status NOT NULL DEFAULT 'ativo',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de empresas
CREATE TABLE public.empresas (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    razao_social TEXT NOT NULL,
    nome_fantasia TEXT,
    cnpj TEXT UNIQUE,
    telefone TEXT,
    email TEXT,
    endereco TEXT,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de clientes
CREATE TABLE public.clientes (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    nome TEXT NOT NULL,
    documento TEXT,
    contato TEXT,
    email TEXT,
    telefone TEXT,
    endereco TEXT,
    tags TEXT[],
    ativo BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de fornecedores
CREATE TABLE public.fornecedores (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    razao_social TEXT NOT NULL,
    cnpj TEXT,
    contato TEXT,
    email TEXT,
    telefone TEXT,
    endereco TEXT,
    ativo BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de tipos de vistoria
CREATE TABLE public.tipos_vistoria (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    nome TEXT NOT NULL,
    descricao TEXT,
    ativo BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de checklists modelo
CREATE TABLE public.checklists_modelo (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    tipo_vistoria_id UUID REFERENCES public.tipos_vistoria(id) NOT NULL,
    nome TEXT NOT NULL,
    descricao TEXT,
    itens JSONB,
    versao INTEGER NOT NULL DEFAULT 1,
    ativo BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de ordens de serviço
CREATE TABLE public.ordens_servico (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    codigo TEXT NOT NULL,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    cliente_id UUID REFERENCES public.clientes(id) NOT NULL,
    tipo_vistoria_id UUID REFERENCES public.tipos_vistoria(id) NOT NULL,
    status os_status NOT NULL DEFAULT 'rascunho',
    prioridade os_prioridade NOT NULL DEFAULT 'media',
    descricao TEXT,
    data_agendada TIMESTAMP WITH TIME ZONE,
    responsavel_id UUID REFERENCES public.usuarios(id),
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar índice para código da OS
CREATE INDEX idx_ordens_servico_codigo ON public.ordens_servico(codigo);

-- Tabela de locais de vistoria
CREATE TABLE public.locais_vistoria (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    ordem_servico_id UUID REFERENCES public.ordens_servico(id) NOT NULL,
    endereco TEXT NOT NULL,
    cidade TEXT,
    uf TEXT,
    cep TEXT,
    latitude DECIMAL,
    longitude DECIMAL
);

-- Tabela de execuções de checklist
CREATE TABLE public.execucoes_checklist (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    ordem_servico_id UUID REFERENCES public.ordens_servico(id) NOT NULL,
    checklist_modelo_id UUID REFERENCES public.checklists_modelo(id) NOT NULL,
    versao_modelo INTEGER NOT NULL,
    inicio TIMESTAMP WITH TIME ZONE,
    fim TIMESTAMP WITH TIME ZONE,
    status execucao_status NOT NULL DEFAULT 'em_execucao',
    observacoes TEXT,
    usuario_id UUID REFERENCES public.usuarios(id) NOT NULL
);

-- Tabela de respostas do checklist
CREATE TABLE public.respostas_checklist (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    execucao_id UUID REFERENCES public.execucoes_checklist(id) NOT NULL,
    item_id TEXT NOT NULL,
    pergunta TEXT NOT NULL,
    tipo resposta_tipo NOT NULL,
    resposta JSONB,
    observacao TEXT
);

-- Tabela de anexos
CREATE TABLE public.anexos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    referencia_tipo referencia_tipo NOT NULL,
    referencia_id UUID NOT NULL,
    arquivo_url TEXT NOT NULL,
    tipo TEXT,
    tamanho BIGINT,
    usuario_id UUID REFERENCES public.usuarios(id) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de fotos
CREATE TABLE public.fotos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    execucao_id UUID REFERENCES public.execucoes_checklist(id) NOT NULL,
    url TEXT NOT NULL,
    legenda TEXT,
    geo_lat DECIMAL,
    geo_lng DECIMAL,
    capturada_em TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    usuario_id UUID REFERENCES public.usuarios(id) NOT NULL
);

-- Tabela de históricos
CREATE TABLE public.historicos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    entidade TEXT NOT NULL,
    entidade_id TEXT NOT NULL,
    acao TEXT NOT NULL,
    descricao TEXT,
    usuario_id UUID REFERENCES public.usuarios(id) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- TABELAS FINANCEIRAS

-- Tabela de contas bancárias
CREATE TABLE public.contas_bancarias (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    nome TEXT NOT NULL,
    banco TEXT,
    agencia TEXT,
    conta TEXT,
    saldo_inicial DECIMAL(15,2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Tabela de movimentos bancários
CREATE TABLE public.movimentos_bancarios (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    conta_id UUID REFERENCES public.contas_bancarias(id) NOT NULL,
    data DATE NOT NULL,
    tipo movimento_tipo NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    descricao TEXT,
    conciliado BOOLEAN NOT NULL DEFAULT false,
    origem_tipo origem_tipo,
    origem_id UUID,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar índice para data dos movimentos
CREATE INDEX idx_movimentos_bancarios_data ON public.movimentos_bancarios(data);

-- Tabela de centros de custos
CREATE TABLE public.centros_custos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    nome TEXT NOT NULL,
    codigo TEXT,
    ativo BOOLEAN NOT NULL DEFAULT true
);

-- Tabela de categorias financeiras
CREATE TABLE public.categorias_financeiras (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    nome TEXT NOT NULL,
    tipo categoria_tipo NOT NULL,
    codigo TEXT,
    ativo BOOLEAN NOT NULL DEFAULT true
);

-- Tabela de contas a receber
CREATE TABLE public.contas_receber (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    cliente_id UUID REFERENCES public.clientes(id) NOT NULL,
    os_id UUID REFERENCES public.ordens_servico(id),
    descricao TEXT NOT NULL,
    categoria_id UUID REFERENCES public.categorias_financeiras(id),
    centro_custos_id UUID REFERENCES public.centros_custos(id),
    emissao DATE NOT NULL,
    vencimento DATE NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    desconto DECIMAL(15,2) NOT NULL DEFAULT 0,
    juros DECIMAL(15,2) NOT NULL DEFAULT 0,
    multa DECIMAL(15,2) NOT NULL DEFAULT 0,
    status conta_status NOT NULL DEFAULT 'aberto',
    observacoes TEXT
);

-- Criar índice para vencimento das contas a receber
CREATE INDEX idx_contas_receber_vencimento ON public.contas_receber(vencimento);

-- Tabela de recebimentos
CREATE TABLE public.recebimentos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    conta_receber_id UUID REFERENCES public.contas_receber(id) NOT NULL,
    data DATE NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    conta_bancaria_id UUID REFERENCES public.contas_bancarias(id) NOT NULL,
    forma_pagamento forma_pagamento NOT NULL,
    comprovante_url TEXT
);

-- Tabela de contas a pagar
CREATE TABLE public.contas_pagar (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    fornecedor_id UUID REFERENCES public.fornecedores(id) NOT NULL,
    compra_id UUID,
    descricao TEXT NOT NULL,
    categoria_id UUID REFERENCES public.categorias_financeiras(id),
    centro_custos_id UUID REFERENCES public.centros_custos(id),
    emissao DATE NOT NULL,
    vencimento DATE NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    desconto DECIMAL(15,2) NOT NULL DEFAULT 0,
    juros DECIMAL(15,2) NOT NULL DEFAULT 0,
    multa DECIMAL(15,2) NOT NULL DEFAULT 0,
    status conta_status NOT NULL DEFAULT 'aberto',
    observacoes TEXT
);

-- Criar índice para vencimento das contas a pagar
CREATE INDEX idx_contas_pagar_vencimento ON public.contas_pagar(vencimento);

-- Tabela de pagamentos
CREATE TABLE public.pagamentos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    conta_pagar_id UUID REFERENCES public.contas_pagar(id) NOT NULL,
    data DATE NOT NULL,
    valor DECIMAL(15,2) NOT NULL,
    conta_bancaria_id UUID REFERENCES public.contas_bancarias(id) NOT NULL,
    forma_pagamento forma_pagamento NOT NULL,
    comprovante_url TEXT
);

-- Tabela de produtos e serviços
CREATE TABLE public.produtos_servicos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    tipo produto_tipo NOT NULL,
    nome TEXT NOT NULL,
    codigo TEXT,
    unidade TEXT,
    preco_venda DECIMAL(15,2),
    custo DECIMAL(15,2),
    ativo BOOLEAN NOT NULL DEFAULT true
);

-- Tabela de compras
CREATE TABLE public.compras (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    empresa_id UUID REFERENCES public.empresas(id) NOT NULL,
    fornecedor_id UUID REFERENCES public.fornecedores(id) NOT NULL,
    numero TEXT NOT NULL,
    data DATE NOT NULL,
    status compra_status NOT NULL DEFAULT 'rascunho',
    observacoes TEXT
);

-- Tabela de itens de compras
CREATE TABLE public.compras_itens (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    compra_id UUID REFERENCES public.compras(id) NOT NULL,
    produto_servico_id UUID REFERENCES public.produtos_servicos(id) NOT NULL,
    descricao TEXT NOT NULL,
    qtd DECIMAL(10,3) NOT NULL,
    preco_unit DECIMAL(15,2) NOT NULL,
    total DECIMAL(15,2) NOT NULL
);

-- Tabela de faturamentos
CREATE TABLE public.faturamentos (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    os_id UUID REFERENCES public.ordens_servico(id) NOT NULL,
    cliente_id UUID REFERENCES public.clientes(id) NOT NULL,
    emissao DATE NOT NULL,
    total DECIMAL(15,2) NOT NULL,
    observacoes TEXT
);

-- Adicionar FK de compra_id na tabela contas_pagar
ALTER TABLE public.contas_pagar ADD CONSTRAINT fk_contas_pagar_compra 
    FOREIGN KEY (compra_id) REFERENCES public.compras(id);

-- Criar índice para documento dos clientes
CREATE INDEX idx_clientes_documento ON public.clientes(documento);

-- Habilitar RLS em todas as tabelas
ALTER TABLE public.usuarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.empresas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clientes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fornecedores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tipos_vistoria ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checklists_modelo ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ordens_servico ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.locais_vistoria ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.execucoes_checklist ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.respostas_checklist ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.anexos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fotos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.historicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contas_bancarias ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.movimentos_bancarios ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.centros_custos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categorias_financeiras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contas_receber ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.recebimentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contas_pagar ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pagamentos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compras ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.compras_itens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.produtos_servicos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.faturamentos ENABLE ROW LEVEL SECURITY;

-- Função para atualizar timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar triggers para atualizar updated_at
CREATE TRIGGER update_usuarios_updated_at BEFORE UPDATE ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_empresas_updated_at BEFORE UPDATE ON public.empresas FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_clientes_updated_at BEFORE UPDATE ON public.clientes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fornecedores_updated_at BEFORE UPDATE ON public.fornecedores FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tipos_vistoria_updated_at BEFORE UPDATE ON public.tipos_vistoria FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_checklists_modelo_updated_at BEFORE UPDATE ON public.checklists_modelo FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_ordens_servico_updated_at BEFORE UPDATE ON public.ordens_servico FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();